package com.anru.studio.ui.screens

import android.net.Uri
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.BluetoothAudio
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.anru.studio.data.model.AppThemeMode
import com.anru.studio.tools.VaultAuthHelper
import com.anru.studio.ui.AnruViewModel
import com.anru.studio.ui.components.MediaArtwork
import com.anru.studio.ui.theme.LiquidGlassBox
import com.anru.studio.ui.theme.LocalAnruColors
import com.anru.studio.ui.theme.OriginSpringFloat
import com.anru.studio.ui.theme.formatFileSize
import kotlinx.coroutines.launch

@Composable
fun StudioScreen(
    vm: AnruViewModel,
    onPickAvatar: () -> Unit,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
    onRequestDeleteUris: (List<Uri>) -> Unit
) {
    val c = LocalAnruColors.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs by vm.userPrefs.collectAsState()
    val songs by vm.visibleSongs.collectAsState()
    val videos by vm.visibleVideos.collectAsState()
    val history by vm.playHistory.collectAsState()
    val allFolders by vm.allMediaFolders.collectAsState()
    val hiddenFolders by vm.hiddenFolders.collectAsState()
    val duplicates by vm.duplicateGroups.collectAsState()
    val vaultedSongs by vm.vaultedSongs.collectAsState()
    val vaultedVideos by vm.vaultedVideos.collectAsState()

    val weeklyStats = remember(history) { vm.computeWeeklyStats(history) }
    val topSongs = remember(history) { vm.computeTopSongs(history) }
    val totalMinutes = remember(history) { history.sumOf { it.durationSec } / 60 }

    var showNameDialog by remember { mutableStateOf(false) }
    var showWrapped by remember { mutableStateOf(false) }
    var showFolderFilterDialog by remember { mutableStateOf(false) }
    var showDuplicatesDialog by remember { mutableStateOf(false) }
    var showVaultPinDialog by remember { mutableStateOf(false) }
    var showVaultUnlocked by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 170.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Holographic Profile Card
        LiquidGlassBox(elevated = true, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(modifier = Modifier.clickable { onPickAvatar() }) {
                    MediaArtwork(model = prefs.profileAvatarUri, size = 66.dp, cornerRadius = 33.dp)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(prefs.profileName, color = c.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Icon(
                            Icons.Rounded.Edit,
                            contentDescription = "Edit Name",
                            tint = c.accentPrimary,
                            modifier = Modifier.size(16.dp).clickable { showNameDialog = true }
                        )
                    }
                    Text("Native Pro • ${songs.size} Songs • ${videos.size} Videos", color = c.textMuted, fontSize = 12.sp)
                }
                IconButton(onClick = { vm.scanDeviceMedia(); vm.showToast("Rescanned phone media ⚡") }) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Rescan", tint = c.accentPrimary)
                }
            }
        }

        // Music Wrapped Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.horizontalGradient(listOf(c.accentPrimary.copy(alpha = 0.25f), c.accentSecondary.copy(alpha = 0.28f))))
                .border(1.dp, c.glassBorderTop, RoundedCornerShape(20.dp))
                .clickable { showWrapped = true }
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = c.accentPrimary, modifier = Modifier.size(28.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Anru Music Wrapped", color = c.textPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    Text("View your listening celebration & top tracks", color = c.textSecondary, fontSize = 12.sp)
                }
            }
        }

        // ONLY 2 THEMES: Origin Glass (iOS / OriginOS 7) & Cyber
        StudioSectionTitle(Icons.Rounded.Palette, "App Theme")
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AppThemeMode.entries.forEach { mode ->
                val selected = prefs.themeMode == mode
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            if (selected) Brush.horizontalGradient(listOf(c.accentPrimary, c.accentSecondary))
                            else Brush.horizontalGradient(listOf(c.glassSurface, c.glassSurface))
                        )
                        .border(1.dp, if (selected) Color.Transparent else c.glassBorderTop, RoundedCornerShape(18.dp))
                        .clickable { scope.launch { vm.prefs.setTheme(mode) } }
                        .padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = mode.label,
                        color = if (selected) Color.Black else c.textPrimary,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.5.sp
                    )
                }
            }
        }

        // Listening Activity Graph (7-day Animated Bar Chart)
        LiquidGlassBox(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Listening Activity (7 Days)", color = c.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("${String.format("%.1f", totalMinutes / 60f)}h • ${history.size} plays", color = c.accentPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                val maxMin = (weeklyStats.maxOfOrNull { it.minutes } ?: 1).coerceAtLeast(1)
                Row(
                    modifier = Modifier.fillMaxWidth().height(92.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.Bottom
                ) {
                    weeklyStats.forEach { st ->
                        val frac by animateFloatAsState(
                            targetValue = (st.minutes.toFloat() / maxMin.toFloat()).coerceIn(0.08f, 1f),
                            animationSpec = OriginSpringFloat,
                            label = "bar_${st.label}"
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                            Box(
                                modifier = Modifier
                                    .width(18.dp)
                                    .fillMaxHeight(frac * 0.78f)
                                    .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                    .background(Brush.verticalGradient(listOf(c.accentPrimary, c.accentSecondary)))
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(st.label, color = c.textMuted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // Smart Audio Filter & Bluetooth Controls
        StudioSectionTitle(Icons.Rounded.FilterList, "Smart Filter & Bluetooth")
        LiquidGlassBox(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                StudioSwitchRow(
                    title = "Hide Call Recordings",
                    subtitle = "Short songs & Reels always stay playable",
                    checked = prefs.filterCallRecordings
                ) { checked ->
                    scope.launch {
                        vm.prefs.setFilterCallRecordings(checked)
                        vm.scanDeviceMedia()
                    }
                }
                StudioSwitchRow(
                    title = "Hide WhatsApp Voice Notes",
                    subtitle = "Skip PTT voice notes & sent audio",
                    checked = prefs.filterWhatsAppVoice
                ) { checked ->
                    scope.launch {
                        vm.prefs.setFilterWhatsAppVoice(checked)
                        vm.scanDeviceMedia()
                    }
                }
                StudioSwitchRow(
                    title = "Bluetooth Auto-Resume",
                    subtitle = "Auto-resume on connect & pause on disconnect",
                    checked = prefs.bluetoothAutoResume
                ) { checked ->
                    scope.launch { vm.prefs.setBluetoothAutoResume(checked) }
                }
                TextButton(onClick = { showFolderFilterDialog = true }) {
                    Text("Manage Hidden Folders (${hiddenFolders.size})", color = c.accentPrimary, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Native Pro Tools (Private Vault, Duplicate Cleaner, Backup & Restore)
        StudioSectionTitle(Icons.Rounded.BluetoothAudio, "Pro Native Tools")

        StudioActionTile(
            icon = Icons.Rounded.Lock,
            title = "Private Vault (${vaultedSongs.size + vaultedVideos.size} Hidden)",
            subtitle = "Fingerprint / PIN lock for private songs & videos",
            tint = c.accentSecondary
        ) {
            val act = ctx as? FragmentActivity
            if (act != null && VaultAuthHelper.canUseBiometrics(ctx)) {
                VaultAuthHelper.authenticateBiometric(
                    activity = act,
                    onSuccess = { showVaultUnlocked = true },
                    onFallbackPin = { showVaultPinDialog = true }
                )
            } else {
                showVaultPinDialog = true
            }
        }

        StudioActionTile(
            icon = Icons.Rounded.CleaningServices,
            title = "Duplicate Media Cleaner",
            subtitle = "Find duplicate songs & videos to free phone space",
            tint = c.accentPrimary
        ) {
            vm.scanDuplicates()
            showDuplicatesDialog = true
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            LiquidGlassBox(
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.weight(1f).clickable { onExportBackup() }
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Rounded.Backup, contentDescription = null, tint = c.accentPrimary)
                    Text("Backup JSON", color = c.textPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
            LiquidGlassBox(
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.weight(1f).clickable { onImportBackup() }
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Rounded.Restore, contentDescription = null, tint = c.accentSecondary)
                    Text("Restore JSON", color = c.textPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }

    // Edit Profile Name Dialog
    if (showNameDialog) {
        var nameInput by remember { mutableStateOf(prefs.profileName) }
        AlertDialog(
            onDismissRequest = { showNameDialog = false },
            title = { Text("Edit Profile Name") },
            text = { OutlinedTextField(value = nameInput, onValueChange = { nameInput = it }, singleLine = true) },
            confirmButton = {
                Button(onClick = {
                    scope.launch { vm.prefs.setProfileName(nameInput) }
                    showNameDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showNameDialog = false }) { Text("Cancel") } }
        )
    }

    // Anru Music Wrapped Dialog
    if (showWrapped) {
        val top1 = topSongs.firstOrNull()
        AlertDialog(
            onDismissRequest = { showWrapped = false },
            title = { Text("ANRU STUDIO WRAPPED") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(prefs.profileName, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                    Text("Total Listening: ${String.format("%.1f", totalMinutes / 60f)} hours (${history.size} plays)")
                    if (top1 != null) {
                        LiquidGlassBox(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("#1 MOST PLAYED", color = c.accentPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(top1.title, color = c.textPrimary, fontWeight = FontWeight.Bold)
                                Text("${top1.artist} • ${top1.playCount} plays", color = c.textMuted, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showWrapped = false }) { Text("Close") } }
        )
    }

    // Custom Folder Hide/Show Dialog
    if (showFolderFilterDialog) {
        AlertDialog(
            onDismissRequest = { showFolderFilterDialog = false },
            title = { Text("Hide / Show Folders") },
            text = {
                Column(modifier = Modifier.height(300.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    allFolders.forEach { folder ->
                        val isHidden = hiddenFolders.any { it.equals(folder, ignoreCase = true) }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(folder, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Switch(checked = !isHidden, onCheckedChange = { vm.toggleFolderHidden(folder) })
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showFolderFilterDialog = false }) { Text("Done") } }
        )
    }

    // Duplicate Cleaner Dialog
    if (showDuplicatesDialog) {
        AlertDialog(
            onDismissRequest = { showDuplicatesDialog = false },
            title = { Text("Duplicate Media Cleaner") },
            text = {
                Column(modifier = Modifier.height(320.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (duplicates.isEmpty()) {
                        Text("No duplicate songs or videos found! Your storage is clean.")
                    } else {
                        duplicates.forEach { grp ->
                            LiquidGlassBox(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "${if (grp.isVideo) "Video" else "Song"} • ${grp.items.size} copies (${formatFileSize(grp.sizeBytes)} each)",
                                        color = c.accentPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    grp.items.forEachIndexed { idx, entry ->
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(entry.title, color = c.textPrimary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text(entry.folderName, color = c.textMuted, fontSize = 10.sp)
                                            }
                                            if (idx > 0) {
                                                IconButton(onClick = {
                                                    onRequestDeleteUris(listOf(entry.uri))
                                                    showDuplicatesDialog = false
                                                }) {
                                                    Icon(Icons.Rounded.Delete, contentDescription = "Delete copy", tint = c.danger, modifier = Modifier.size(18.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showDuplicatesDialog = false }) { Text("Close") } }
        )
    }

    // Vault PIN Setup / Unlock Dialog
    if (showVaultPinDialog) {
        var pinInput by remember { mutableStateOf("") }
        val hasPin = prefs.vaultPin.isNotEmpty()
        AlertDialog(
            onDismissRequest = { showVaultPinDialog = false },
            title = { Text(if (hasPin) "Enter Vault PIN" else "Set 4-Digit Vault PIN") },
            text = {
                OutlinedTextField(
                    value = pinInput,
                    onValueChange = { if (it.length <= 6) pinInput = it.filter { ch -> ch.isDigit() } },
                    placeholder = { Text("Enter 4-digit PIN") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (!hasPin && pinInput.length >= 4) {
                        scope.launch { vm.prefs.setVaultPin(pinInput) }
                        showVaultPinDialog = false
                        showVaultUnlocked = true
                    } else if (hasPin && pinInput == prefs.vaultPin) {
                        showVaultPinDialog = false
                        showVaultUnlocked = true
                    } else {
                        vm.showToast("Invalid PIN")
                    }
                }) { Text(if (hasPin) "Unlock" else "Save PIN") }
            },
            dismissButton = { TextButton(onClick = { showVaultPinDialog = false }) { Text("Cancel") } }
        )
    }

    // Unlocked Private Vault Dialog
    if (showVaultUnlocked) {
        AlertDialog(
            onDismissRequest = { showVaultUnlocked = false },
            title = { Text("Private Vault (Unlocked)") },
            text = {
                Column(modifier = Modifier.height(320.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (vaultedSongs.isEmpty() && vaultedVideos.isEmpty()) {
                        Text("Vault is empty. Use the 3-dots menu on any song or video to hide it here.")
                    }
                    vaultedSongs.forEach { s ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { vm.playSong(s, vaultedSongs) }) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("🎵 ${s.title}", fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(s.artist, color = c.textMuted, fontSize = 11.sp)
                            }
                            IconButton(onClick = { vm.removeFromVault(s.id, isVideo = false) }) {
                                Icon(Icons.Rounded.LockOpen, contentDescription = "Unhide", tint = c.accentPrimary)
                            }
                        }
                    }
                    vaultedVideos.forEach { v ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable {
                            showVaultUnlocked = false
                            vm.openVideo(v, vaultedVideos)
                        }) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("🎬 ${v.title}", fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(formatFileSize(v.sizeBytes), color = c.textMuted, fontSize = 11.sp)
                            }
                            IconButton(onClick = { vm.removeFromVault(v.id, isVideo = true) }) {
                                Icon(Icons.Rounded.LockOpen, contentDescription = "Unhide", tint = c.accentPrimary)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showVaultUnlocked = false },
                    colors = ButtonDefaults.buttonColors(containerColor = c.accentPrimary)
                ) { Text("Lock Vault", color = Color.Black, fontWeight = FontWeight.Bold) }
            }
        )
    }
}

@Composable
private fun StudioSectionTitle(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String) {
    val c = LocalAnruColors.current
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(icon, contentDescription = null, tint = c.accentPrimary, modifier = Modifier.size(18.dp))
        Text(title, color = c.textPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
    }
}

@Composable
private fun StudioSwitchRow(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val c = LocalAnruColors.current
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, color = c.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.5.sp)
            Text(subtitle, color = c.textMuted, fontSize = 11.5.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun StudioActionTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    tint: Color,
    onClick: () -> Unit
) {
    val c = LocalAnruColors.current
    LiquidGlassBox(
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(tint.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = tint)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = c.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(subtitle, color = c.textMuted, fontSize = 11.5.sp)
            }
        }
    }
}
