package com.anru.studio

import android.Manifest
import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.anru.studio.data.model.MainTab
import com.anru.studio.ui.AnruViewModel
import com.anru.studio.ui.screens.FloatingMiniPlayer
import com.anru.studio.ui.screens.FullscreenMusicPlayer
import com.anru.studio.ui.screens.LibraryScreen
import com.anru.studio.ui.screens.PlayItVideoPlayerOverlay
import com.anru.studio.ui.screens.PlaylistsScreen
import com.anru.studio.ui.screens.StudioScreen
import com.anru.studio.ui.screens.VideosScreen
import com.anru.studio.ui.theme.AnimatedStudioBackground
import com.anru.studio.ui.theme.AnruStudioTheme
import com.anru.studio.ui.theme.LiquidGlassBox
import com.anru.studio.ui.theme.LocalAnruColors
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {

    private val vm: AnruViewModel by viewModels()
    private var hasMediaPermission by mutableStateOf(false)
    private var pendingArtSongId: Long? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        hasMediaPermission = checkMediaPermissionsGranted()
        if (hasMediaPermission) {
            vm.scanDeviceMedia()
        }
    }

    private val deleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            vm.showToast("Deleted from phone storage")
            vm.scanDeviceMedia()
        }
    }

    private val avatarPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            lifecycleScope.launch { vm.prefs.setProfileAvatar(uri.toString()) }
            vm.showToast("Profile avatar updated!")
        }
    }

    private val songArtPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        val songId = pendingArtSongId
        pendingArtSongId = null
        if (uri != null && songId != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            val song = vm.allScannedSongs.value.find { it.id == songId }
            if (song != null) {
                vm.saveTagOverride(songId, song.title, song.artist, song.album, uri.toString())
            }
        }
    }

    private val backupExportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) vm.exportBackupToUri(uri)
    }

    private val backupImportLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) vm.importBackupFromUri(uri)
    }

    private fun requiredPermissions(): Array<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.POST_NOTIFICATIONS
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    private fun checkMediaPermissionsGranted(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestDeleteUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val pi = vm.buildDeleteRequest(uris)
        if (pi != null) {
            deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else {
            vm.deleteLegacyMedia(uris)
        }
    }

    private fun triggerPictureInPicture() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && vm.activeVideo.value != null) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } catch (_: Exception) {
                vm.showToast("PiP not available right now")
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (vm.activeVideo.value != null) {
            triggerPictureInPicture()
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        vm.setPipMode(isInPictureInPictureMode)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hasMediaPermission = checkMediaPermissionsGranted()

        setContent {
            val prefs by vm.userPrefs.collectAsState()
            val tab by vm.currentTab.collectAsState()
            val activeVideo by vm.activeVideo.collectAsState()
            val activeVideoQueue by vm.activeVideoQueue.collectAsState()
            val isInPip by vm.isInPipMode.collectAsState()
            val toast by vm.toastMessage.collectAsState()
            var showFullscreenMusic by remember { mutableStateOf(false) }

            LaunchedEffect(hasMediaPermission) {
                if (hasMediaPermission) {
                    vm.scanDeviceMedia()
                }
            }

            BackHandler(enabled = activeVideo != null || showFullscreenMusic || tab != MainTab.LIBRARY) {
                when {
                    activeVideo != null -> vm.closeVideo()
                    showFullscreenMusic -> showFullscreenMusic = false
                    tab != MainTab.LIBRARY -> vm.setTab(MainTab.LIBRARY)
                }
            }

            AnruStudioTheme(themeMode = prefs.themeMode) {
                val c = LocalAnruColors.current
                AnimatedStudioBackground {
                    if (!hasMediaPermission) {
                        PermissionGateScreen(
                            onGrant = { permissionLauncher.launch(requiredPermissions()) }
                        )
                    } else {
                        Box(modifier = Modifier.fillMaxSize()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .statusBarsPadding()
                            ) {
                                // Unified Adaptive Top Header
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Image(
                                            painter = painterResource(R.drawable.anru_logo),
                                            contentDescription = "Anru Studio",
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(RoundedCornerShape(12.dp))
                                        )
                                        Column {
                                            Text(
                                                text = if (tab == MainTab.VIDEOS) "Anru Video" else "Anru Studio",
                                                color = c.textPrimary,
                                                fontSize = 18.sp,
                                                fontWeight = FontWeight.ExtraBold
                                            )
                                            Text(
                                                text = if (tab == MainTab.VIDEOS) "PLAYIT 4K PRO" else "NATIVE OFFLINE PRO",
                                                color = c.accentPrimary,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                letterSpacing = 1.2.sp
                                            )
                                        }
                                    }

                                    LiquidGlassBox(shape = CircleShape, modifier = Modifier.size(40.dp)) {
                                        IconButton(onClick = {
                                            vm.scanDeviceMedia()
                                            vm.showToast("Library synced with phone storage ⚡")
                                        }) {
                                            Icon(Icons.Rounded.Refresh, contentDescription = "Sync", tint = c.textPrimary, modifier = Modifier.size(20.dp))
                                        }
                                    }
                                }

                                // Smooth Animated Main Content Switcher
                                Box(modifier = Modifier.weight(1f)) {
                                    AnimatedContent(
                                        targetState = tab,
                                        transitionSpec = {
                                            fadeIn(tween(240)) togetherWith fadeOut(tween(180))
                                        },
                                        label = "mainTabAnim"
                                    ) { current ->
                                        when (current) {
                                            MainTab.LIBRARY -> LibraryScreen(
                                                vm = vm,
                                                onOpenFullscreen = { showFullscreenMusic = true },
                                                onRequestDeleteUris = ::requestDeleteUris,
                                                onPickCustomArt = { songId ->
                                                    pendingArtSongId = songId
                                                    songArtPicker.launch(arrayOf("image/*"))
                                                }
                                            )
                                            MainTab.PLAYLISTS -> PlaylistsScreen(vm = vm)
                                            MainTab.VIDEOS -> VideosScreen(
                                                vm = vm,
                                                onRequestDeleteUris = ::requestDeleteUris
                                            )
                                            MainTab.STUDIO -> StudioScreen(
                                                vm = vm,
                                                onPickAvatar = { avatarPicker.launch(arrayOf("image/*")) },
                                                onExportBackup = { backupExportLauncher.launch("anru_studio_backup.json") },
                                                onImportBackup = { backupImportLauncher.launch(arrayOf("application/json", "*/*")) },
                                                onRequestDeleteUris = ::requestDeleteUris
                                            )
                                        }
                                    }
                                }
                            }

                            // Floating Mini Player + Origin Glass Floating Bottom Navigation Dock
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .navigationBarsPadding()
                                    .padding(bottom = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                FloatingMiniPlayer(
                                    vm = vm,
                                    onExpand = { showFullscreenMusic = true }
                                )

                                LiquidGlassBox(
                                    elevated = true,
                                    shape = RoundedCornerShape(26.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceEvenly
                                    ) {
                                        BottomNavItem("Library", Icons.Rounded.LibraryMusic, tab == MainTab.LIBRARY) { vm.setTab(MainTab.LIBRARY) }
                                        BottomNavItem("Playlists", Icons.Rounded.QueueMusic, tab == MainTab.PLAYLISTS) { vm.setTab(MainTab.PLAYLISTS) }
                                        BottomNavItem("Videos", Icons.Rounded.Movie, tab == MainTab.VIDEOS) { vm.setTab(MainTab.VIDEOS) }
                                        BottomNavItem("Studio", Icons.Rounded.Tune, tab == MainTab.STUDIO) { vm.setTab(MainTab.STUDIO) }
                                    }
                                }
                            }

                            // Fullscreen Music Player Overlay
                            FullscreenMusicPlayer(
                                visible = showFullscreenMusic,
                                vm = vm,
                                onDismiss = { showFullscreenMusic = false }
                            )

                            // Fullscreen PLAYit Video Player Overlay
                            activeVideo?.let { vid ->
                                PlayItVideoPlayerOverlay(
                                    video = vid,
                                    queue = activeVideoQueue,
                                    vm = vm,
                                    isInPipMode = isInPip,
                                    onEnterPip = ::triggerPictureInPicture,
                                    onClose = vm::closeVideo
                                )
                            }

                            // Floating Toast Pill
                            AnimatedVisibility(
                                visible = toast != null && !isInPip,
                                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .statusBarsPadding()
                                    .padding(top = 64.dp)
                            ) {
                                LiquidGlassBox(elevated = true, shape = RoundedCornerShape(50)) {
                                    Text(
                                        text = toast ?: "",
                                        color = c.textPrimary,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomNavItem(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    val c = LocalAnruColors.current
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) c.accentPrimary.copy(alpha = 0.16f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) c.accentPrimary else c.textMuted, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(2.dp))
        Text(label, color = if (selected) c.accentPrimary else c.textMuted, fontSize = 10.5.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable
private fun PermissionGateScreen(onGrant: () -> Unit) {
    val c = LocalAnruColors.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        LiquidGlassBox(elevated = true, shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(26.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Image(
                    painter = painterResource(R.drawable.anru_logo),
                    contentDescription = "Anru Studio",
                    modifier = Modifier.size(84.dp).clip(RoundedCornerShape(22.dp))
                )
                Text("Anru Studio Pro", color = c.textPrimary, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    text = "Allow one-time Media Storage access so Anru Studio can automatically load all your phone songs & videos with 0 MB extra copy — no folder scanning ever again.",
                    color = c.textSecondary,
                    fontSize = 13.5.sp,
                    textAlign = TextAlign.Center
                )
                Button(
                    onClick = onGrant,
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(containerColor = c.accentPrimary),
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    Icon(Icons.Rounded.FolderOpen, contentDescription = null, tint = Color.Black)
                    Spacer(Modifier.size(8.dp))
                    Text("Allow Storage Access", color = Color.Black, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                }
            }
        }
    }
}
