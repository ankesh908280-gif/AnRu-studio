package com.anru.studio.data.repository

import android.app.PendingIntent
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.anru.studio.data.db.TagOverrideEntity
import com.anru.studio.data.db.VideoProgressEntity
import com.anru.studio.data.model.SongItem
import com.anru.studio.data.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaRepository(private val context: Context) {

    private fun isTrashedOrHidden(name: String?): Boolean {
        val clean = (name ?: "").trim().lowercase()
        if (clean.isEmpty()) return true
        return clean.startsWith(".") || clean.startsWith("trashed-") || clean.startsWith(".trashed-")
    }

    private fun isCallRecordingPath(pathLower: String, folderLower: String, nameLower: String): Boolean {
        val keywords = listOf(
            "call_rec", "callrec", "call recording", "call recordings",
            "recordings/call", "miui/sound_recorder/call", "sound_recorder/call",
            "callrecord", "acrrecordings", "cubeacr"
        )
        return keywords.any { pathLower.contains(it) || folderLower.contains(it) } ||
            nameLower.startsWith("call@") || nameLower.startsWith("call_")
    }

    private fun isWhatsAppVoiceOrJunkPath(pathLower: String, folderLower: String, nameLower: String): Boolean {
        val junkPaths = listOf(
            "whatsapp voice notes", "whatsapp audio/sent", "whatsapp/media/whatsapp voice",
            "notifications", "alarms", "ringtones", "telegram/telegram audio/sent"
        )
        return junkPaths.any { pathLower.contains(it) || folderLower.contains(it) } ||
            nameLower.startsWith("ptt-") || nameLower.startsWith("aud-") && pathLower.contains("whatsapp voice")
    }

    suspend fun scanAllSongs(
        filterCallRecordings: Boolean,
        filterWhatsAppVoice: Boolean,
        tagOverrides: Map<Long, TagOverrideEntity>
    ): List<SongItem> = withContext(Dispatchers.IO) {
        val songs = mutableListOf<SongItem>()
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = mutableListOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DISPLAY_NAME
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            projection.add(MediaStore.Audio.Media.RELATIVE_PATH)
            projection.add(MediaStore.Audio.Media.BUCKET_DISPLAY_NAME)
        } else {
            @Suppress("DEPRECATION")
            projection.add(MediaStore.Audio.Media.DATA)
        }

        // NOTE: Intentionally NO 30-second minimum duration cutoff so short downloaded songs/Reels/Shorts play!
        val selection = "${MediaStore.Audio.Media.IS_ALARM} = 0 AND ${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 AND ${MediaStore.Audio.Media.SIZE} > 0"
        val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

        try {
            context.contentResolver.query(
                collection,
                projection.toTypedArray(),
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val relPathCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH)
                } else -1
                val bucketCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.Audio.Media.BUCKET_DISPLAY_NAME)
                } else -1
                @Suppress("DEPRECATION")
                val dataCol = if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                } else -1

                while (cursor.moveToNext()) {
                    val displayName = cursor.getString(nameCol) ?: continue
                    if (isTrashedOrHidden(displayName)) continue

                    val relPath = when {
                        relPathCol >= 0 -> cursor.getString(relPathCol) ?: ""
                        dataCol >= 0 -> cursor.getString(dataCol) ?: ""
                        else -> ""
                    }
                    val folderName = when {
                        bucketCol >= 0 -> cursor.getString(bucketCol)?.takeIf { it.isNotBlank() }
                        else -> relPath.trimEnd('/').substringAfterLast('/', "Music").takeIf { it.isNotBlank() }
                    } ?: "Music"

                    val pathLower = relPath.lowercase()
                    val folderLower = folderName.lowercase()
                    val nameLower = displayName.lowercase()

                    if (filterCallRecordings && isCallRecordingPath(pathLower, folderLower, nameLower)) continue
                    if (filterWhatsAppVoice && isWhatsAppVoiceOrJunkPath(pathLower, folderLower, nameLower)) continue

                    val id = cursor.getLong(idCol)
                    val contentUri = ContentUris.withAppendedId(collection, id)
                    val albumId = cursor.getLong(albumIdCol)
                    val albumArtUri = ContentUris.withAppendedId(
                        Uri.parse("content://media/external/audio/albumart"),
                        albumId
                    )

                    val rawTitle = cursor.getString(titleCol)?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: displayName.substringBeforeLast('.')
                    val rawArtist = cursor.getString(artistCol)?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: "Local Artist"
                    val rawAlbum = cursor.getString(albumCol)?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: folderName

                    val override = tagOverrides[id]
                    songs.add(
                        SongItem(
                            id = id,
                            uri = contentUri,
                            title = override?.title?.takeIf { it.isNotBlank() } ?: rawTitle,
                            artist = override?.artist?.takeIf { it.isNotBlank() } ?: rawArtist,
                            album = override?.album?.takeIf { it.isNotBlank() } ?: rawAlbum,
                            albumArtUri = albumArtUri,
                            customArtUri = override?.customArtUri,
                            durationMs = cursor.getLong(durCol).coerceAtLeast(0L),
                            sizeBytes = cursor.getLong(sizeCol).coerceAtLeast(0L),
                            dateAddedSec = cursor.getLong(dateCol),
                            folderName = folderName,
                            relativePath = relPath,
                            displayName = displayName
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        songs
    }

    suspend fun scanAllVideos(
        progressMap: Map<Long, VideoProgressEntity>
    ): List<VideoItem> = withContext(Dispatchers.IO) {
        val videos = mutableListOf<VideoItem>()
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val projection = mutableListOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            projection.add(MediaStore.Video.Media.RELATIVE_PATH)
            projection.add(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
        } else {
            @Suppress("DEPRECATION")
            projection.add(MediaStore.Video.Media.DATA)
        }

        val selection = "${MediaStore.Video.Media.SIZE} > 0"
        val sortOrder = "${MediaStore.Video.Media.DATE_MODIFIED} DESC"

        try {
            context.contentResolver.query(
                collection,
                projection.toTypedArray(),
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val widthCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val heightCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                val relPathCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.Video.Media.RELATIVE_PATH)
                } else -1
                val bucketCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                } else -1
                @Suppress("DEPRECATION")
                val dataCol = if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.Video.Media.DATA)
                } else -1

                while (cursor.moveToNext()) {
                    val displayName = cursor.getString(nameCol) ?: continue
                    if (isTrashedOrHidden(displayName)) continue

                    val relPath = when {
                        relPathCol >= 0 -> cursor.getString(relPathCol) ?: ""
                        dataCol >= 0 -> cursor.getString(dataCol) ?: ""
                        else -> ""
                    }
                    val folderName = when {
                        bucketCol >= 0 -> cursor.getString(bucketCol)?.takeIf { it.isNotBlank() }
                        else -> relPath.trimEnd('/').substringAfterLast('/', "Videos").takeIf { it.isNotBlank() }
                    } ?: "Videos"

                    val id = cursor.getLong(idCol)
                    val contentUri = ContentUris.withAppendedId(collection, id)
                    val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() }
                        ?: displayName.substringBeforeLast('.')
                    val prog = progressMap[id]

                    videos.add(
                        VideoItem(
                            id = id,
                            uri = contentUri,
                            title = title,
                            displayName = displayName,
                            folderName = folderName,
                            relativePath = relPath,
                            durationMs = cursor.getLong(durCol).coerceAtLeast(0L),
                            sizeBytes = cursor.getLong(sizeCol).coerceAtLeast(0L),
                            dateModifiedSec = cursor.getLong(dateCol),
                            width = cursor.getInt(widthCol),
                            height = cursor.getInt(heightCol),
                            lastPositionMs = prog?.lastPositionMs ?: 0L,
                            lastWatchedAt = prog?.lastWatchedAt ?: 0L
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        videos
    }

    fun buildDeletePendingIntent(uris: List<Uri>): PendingIntent? {
        if (uris.isEmpty()) return null
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            MediaStore.createDeleteRequest(context.contentResolver, uris)
        } else {
            null
        }
    }

    suspend fun deleteLegacyUris(uris: List<Uri>): Int = withContext(Dispatchers.IO) {
        var deleted = 0
        uris.forEach { uri ->
            try {
                if (context.contentResolver.delete(uri, null, null) > 0) deleted++
            } catch (_: Exception) {
            }
        }
        deleted
    }
}
