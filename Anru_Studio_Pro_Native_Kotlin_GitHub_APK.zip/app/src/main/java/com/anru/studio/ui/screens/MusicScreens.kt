package com.anru.studio.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.CheckBox
import androidx.compose.material.icons.rounded.CheckBoxOutlineBlank
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.anru.studio.data.model.RepeatMode
import com.anru.studio.data.model.SongItem
import com.anru.studio.data.model.SongSort
import com.anru.studio.ui.AnruViewModel
import com.anru.studio.ui.components.AnimatedEqBars
import com.anru.studio.ui.components.GlassSearchBar
import com.anru.studio.ui.components.MediaArtwork
import com.anru.studio.ui.theme.LiquidGlassBox
import com.anru.studio.ui.theme.LocalAnruColors
import com.anru.studio.ui.theme.OriginSpringFloat
import com.anru.studio.ui.theme.formatTimeMs
import kotlin.math.abs
import kotlin.math.sin

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    vm: AnruViewModel,
    onOpenFullscreen: () -> Unit,
    onRequestDeleteUris: (List<Uri>) -> Unit,
    onPickCustomArt: (Long) -> Unit
) {
    val c = LocalAnruColors.current
    val allSongs by vm.visibleSongs.collectAsState()
    val query by vm.songSearch.collectAsState()
    val sort by vm.songSort.collectAsState()
    val currentSong by vm.currentSong.collectAsState()
    val isPlaying by vm.isPlaying.collectAsState()
    val playlists by vm.playlists.collectAsState()

    var sortExpanded by remember { mutableStateOf(false) }
    var isSelectMode by remember { mutableStateOf(false) }
    var selectedIds by remember { mutableStateOf(setOf<Long>()) }
    var actionSong by remember { mutableStateOf<SongItem?>(null) }
    var playlistPickerSongs by remember { mutableStateOf<List<SongItem>?>(null) }
    var tagEditSong by remember { mutableStateOf<SongItem?>(null) }
    var trimSong by remember { mutableStateOf<SongItem?>(null) }

    val filteredSongs = remember(allSongs, query, sort) {
        val q = query.trim().lowercase()
        val list = if (q.isEmpty()) allSongs else allSongs.filter {
            it.title.lowercase().contains(q) ||
                it.artist.lowercase().contains(q) ||
                it.album.lowercase().contains(q) ||
                it.folderName.lowercase().contains(q)
        }
        when (sort) {
            SongSort.DATE_NEW -> list.sortedByDescending { it.dateAddedSec }
            SongSort.TITLE_ASC -> list.sortedBy { it.title.lowercase() }
            SongSort.ARTIST_ASC -> list.sortedBy { it.artist.lowercase() }
            SongSort.DURATION_DESC -> list.sortedByDescending { it.durationMs }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        GlassSearchBar(
            query = query,
            placeholder = "Search songs, artists, albums...",
            onQueryChange = vm::setSongSearch
        )
        Spacer(Modifier.height(12.dp))

        // Clean Meta Row (NO 0 MB Copy badge!)
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            LiquidGlassBox(shape = RoundedCornerShape(50)) {
                Text(
                    text = "${filteredSongs.size} Songs",
                    color = c.textPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                )
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LiquidGlassBox(
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.clickable {
                        if (isSelectMode) {
                            isSelectMode = false
                            selectedIds = emptySet()
                        } else {
                            isSelectMode = true
                        }
                    }
                ) {
                    Text(
                        text = if (isSelectMode) "Cancel (${selectedIds.size})" else "Select",
                        color = if (isSelectMode) c.accentPrimary else c.textSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp)
                    )
                }

                Box {
                    LiquidGlassBox(
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.clickable { sortExpanded = true }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Rounded.Sort, contentDescription = null, tint = c.accentPrimary, modifier = Modifier.size(15.dp))
                            Text(sort.label, color = c.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                    DropdownMenu(expanded = sortExpanded, onDismissRequest = { sortExpanded = false }) {
                        SongSort.entries.forEach { s ->
                            DropdownMenuItem(
                                text = { Text(s.label) },
                                onClick = {
                                    vm.setSongSort(s)
                                    sortExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        AnimatedVisibility(visible = isSelectMode && selectedIds.isNotEmpty()) {
            LiquidGlassBox(
                elevated = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = {
                        selectedIds = if (selectedIds.size == filteredSongs.size) emptySet()
                        else filteredSongs.map { it.id }.toSet()
                    }) {
                        Text(if (selectedIds.size == filteredSongs.size) "Clear All" else "Select All", color = c.accentPrimary)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(onClick = {
                            val chosen = filteredSongs.filter { it.id in selectedIds }
                            playlistPickerSongs = chosen
                        }) {
                            Icon(Icons.Rounded.PlaylistAdd, contentDescription = "Add to Playlist", tint = c.textPrimary)
                        }
                        IconButton(onClick = {
                            selectedIds.forEach { vm.moveToVault(it, isVideo = false) }
                            isSelectMode = false
                            selectedIds = emptySet()
                        }) {
                            Icon(Icons.Rounded.Lock, contentDescription = "Move to Vault", tint = c.accentSecondary)
                        }
                        IconButton(onClick = {
                            val uris = filteredSongs.filter { it.id in selectedIds }.map { it.uri }
                            onRequestDeleteUris(uris)
                            isSelectMode = false
                            selectedIds = emptySet()
                        }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = c.danger)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        if (filteredSongs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = c.textMuted, modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("No songs found on device", color = c.textSecondary, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text("All phone music loads automatically — 0 MB copy", color = c.textMuted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 170.dp)
            ) {
                itemsIndexed(filteredSongs, key = { _, s -> s.id }) { idx, song ->
                    val isCurrent = currentSong?.id == song.id
                    val isSel = song.id in selectedIds
                    LiquidGlassBox(
                        elevated = isCurrent || isSel,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .combinedClickable(
                                onClick = {
                                    if (isSelectMode) {
                                        selectedIds = if (isSel) selectedIds - song.id else selectedIds + song.id
                                    } else if (isCurrent) {
                                        onOpenFullscreen()
                                    } else {
                                        vm.playSong(song, filteredSongs)
                                    }
                                },
                                onLongClick = {
                                    isSelectMode = true
                                    selectedIds = selectedIds + song.id
                                }
                            )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            if (isSelectMode) {
                                Icon(
                                    imageVector = if (isSel) Icons.Rounded.CheckBox else Icons.Rounded.CheckBoxOutlineBlank,
                                    contentDescription = null,
                                    tint = if (isSel) c.accentPrimary else c.textMuted
                                )
                            } else {
                                Text(
                                    text = "${idx + 1}",
                                    color = if (isCurrent) c.accentPrimary else c.textMuted,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(24.dp)
                                )
                            }

                            Box(contentAlignment = Alignment.Center) {
                                MediaArtwork(model = song.customArtUri ?: song.albumArtUri, size = 48.dp, cornerRadius = 13.dp)
                                if (isCurrent) {
                                    Box(
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(RoundedCornerShape(13.dp))
                                            .background(Color.Black.copy(alpha = 0.45f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        AnimatedEqBars(isPlaying = isPlaying)
                                    }
                                }
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = song.title,
                                    color = if (isCurrent) c.accentPrimary else c.textPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${song.artist} • ${formatTimeMs(song.durationMs)}",
                                    color = c.textMuted,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            if (!isSelectMode) {
                                IconButton(onClick = { actionSong = song }) {
                                    Icon(Icons.Rounded.MoreVert, contentDescription = "Options", tint = c.textMuted)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 3-Dots Song Action Sheet
    actionSong?.let { song ->
        ModalBottomSheet(
            onDismissRequest = { actionSong = null },
            containerColor = c.bgTop
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(bottom = 10.dp)
                ) {
                    MediaArtwork(model = song.customArtUri ?: song.albumArtUri, size = 48.dp)
                    Column {
                        Text(song.title, color = c.textPrimary, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${song.artist} • ${song.folderName}", color = c.textMuted, fontSize = 12.sp)
                    }
                }

                SheetOptionRow(Icons.Rounded.PlayArrow, "Play Next", c.textPrimary) {
                    vm.addToQueue(song, playNext = true)
                    actionSong = null
                }
                SheetOptionRow(Icons.Rounded.QueueMusic, "Add to Queue", c.textPrimary) {
                    vm.addToQueue(song, playNext = false)
                    actionSong = null
                }
                SheetOptionRow(Icons.Rounded.PlaylistAdd, "Add to Playlist", c.textPrimary) {
                    playlistPickerSongs = listOf(song)
                    actionSong = null
                }
                SheetOptionRow(Icons.Rounded.Edit, "Edit Song Tag & Cover", c.accentPrimary) {
                    tagEditSong = song
                    actionSong = null
                }
                SheetOptionRow(Icons.Rounded.ContentCut, "Ringtone Cutter / Trimmer", c.accentSecondary) {
                    trimSong = song
                    actionSong = null
                }
                SheetOptionRow(Icons.Rounded.Lock, "Hide in Private Vault", c.textPrimary) {
                    vm.moveToVault(song.id, isVideo = false)
                    actionSong = null
                }
                SheetOptionRow(Icons.Rounded.Delete, "Delete from Phone", c.danger) {
                    onRequestDeleteUris(listOf(song.uri))
                    actionSong = null
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }

    // Add to Playlist Picker Dialog
    playlistPickerSongs?.let { songsToAdd ->
        var newPlName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { playlistPickerSongs = null },
            title = { Text("Add to Playlist") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = newPlName,
                            onValueChange = { newPlName = it },
                            placeholder = { Text("New playlist name") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = {
                            if (newPlName.isNotBlank()) {
                                vm.createPlaylist(newPlName)
                                newPlName = ""
                            }
                        }) {
                            Icon(Icons.Rounded.Add, contentDescription = "Create")
                        }
                    }
                    playlists.forEach { pl ->
                        LiquidGlassBox(
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    songsToAdd.forEach { s -> vm.addSongToPlaylist(pl.id, s.id) }
                                    playlistPickerSongs = null
                                    isSelectMode = false
                                    selectedIds = emptySet()
                                }
                        ) {
                            Text(pl.name, color = c.textPrimary, modifier = Modifier.padding(12.dp), fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { playlistPickerSongs = null }) { Text("Close") }
            }
        )
    }

    // In-App Song Tag & Cover Editor Dialog
    tagEditSong?.let { song ->
        var title by remember(song) { mutableStateOf(song.title) }
        var artist by remember(song) { mutableStateOf(song.artist) }
        var album by remember(song) { mutableStateOf(song.album) }
        AlertDialog(
            onDismissRequest = { tagEditSong = null },
            title = { Text("Edit Song Tag & Cover") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        MediaArtwork(model = song.customArtUri ?: song.albumArtUri, size = 56.dp)
                        TextButton(onClick = {
                            onPickCustomArt(song.id)
                            tagEditSong = null
                        }) {
                            Text("Change Cover Art")
                        }
                    }
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, singleLine = true)
                    OutlinedTextField(value = artist, onValueChange = { artist = it }, label = { Text("Artist") }, singleLine = true)
                    OutlinedTextField(value = album, onValueChange = { album = it }, label = { Text("Album") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    vm.saveTagOverride(song.id, title, artist, album, song.customArtUri)
                    tagEditSong = null
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { tagEditSong = null }) { Text("Cancel") }
            }
        )
    }

    // Ringtone Cutter / Audio Trimmer Dialog
    trimSong?.let { song ->
        RingtoneCutterDialog(song = song, vm = vm, onDismiss = { trimSong = null })
    }
}

@Composable
fun RingtoneCutterDialog(
    song: SongItem,
    vm: AnruViewModel,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val maxDur = song.durationMs.coerceAtLeast(1000L).toFloat()
    var range by remember(song) { mutableStateOf(0f..minOf(maxDur, 30_000f)) }
    var setAsDefault by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Ringtone Cutter") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(song.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Range: ${formatTimeMs(range.start.toLong())} → ${formatTimeMs(range.endInclusive.toLong())}", fontSize = 13.sp)
                RangeSlider(
                    value = range,
                    onValueChange = { if (it.endInclusive - it.start >= 1000f) range = it },
                    valueRange = 0f..maxDur
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = setAsDefault, onCheckedChange = { setAsDefault = it })
                    Text("Set as Phone Ringtone", fontSize = 13.sp)
                }
                if (setAsDefault && !Settings.System.canWrite(ctx)) {
                    TextButton(onClick = {
                        val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                        ctx.startActivity(intent)
                    }) {
                        Text("Grant Modify System Settings Permission")
                    }
                }
            }
        },
        confirmButton = {
            Button(
                enabled = !busy,
                onClick = {
                    busy = true
                    vm.trimRingtone(
                        song = song,
                        startMs = range.start.toLong(),
                        endMs = range.endInclusive.toLong(),
                        setAsDefault = setAsDefault
                    ) { _, msg ->
                        busy = false
                        vm.showToast(msg)
                        onDismiss()
                    }
                }
            ) {
                Text(if (busy) "Trimming..." else "Save Cut")
            }
        },
        dismissButton = {
            TextButton(enabled = !busy, onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun SheetOptionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(21.dp))
        Text(label, color = tint, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun PlaylistsScreen(
    vm: AnruViewModel
) {
    val c = LocalAnruColors.current
    val playlists by vm.playlists.collectAsState()
    val refs by vm.playlistRefs.collectAsState()
    val songs by vm.visibleSongs.collectAsState()
    val favIds by vm.favoriteIds.collectAsState()
    val history by vm.playHistory.collectAsState()

    var showCreate by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var openTitle by remember { mutableStateOf<String?>(null) }
    var openPlaylistId by remember { mutableStateOf<Long?>(null) }
    var openSongs by remember { mutableStateOf<List<SongItem>>(emptyList()) }

    val songMap = remember(songs) { songs.associateBy { it.id } }
    val favSongs = remember(songs, favIds) {
        val set = favIds.toSet()
        songs.filter { it.id in set }
    }
    val mostPlayedSongs = remember(songs, history) {
        val counts = history.groupingBy { it.songId }.eachCount()
        songs.filter { (counts[it.id] ?: 0) > 0 }.sortedByDescending { counts[it.id] ?: 0 }
    }
    val neverPlayedSongs = remember(songs, history) {
        val played = history.map { it.songId }.toSet()
        songs.filter { it.id !in played }
    }

    if (openTitle != null) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(onClick = { openTitle = null; openPlaylistId = null }) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = c.textPrimary)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(openTitle ?: "", color = c.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("${openSongs.size} Songs", color = c.textMuted, fontSize = 12.sp)
                }
                if (openPlaylistId != null) {
                    IconButton(onClick = {
                        vm.deletePlaylist(openPlaylistId!!)
                        openTitle = null
                        openPlaylistId = null
                    }) {
                        Icon(Icons.Rounded.Delete, contentDescription = "Delete Playlist", tint = c.danger)
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                Button(
                    onClick = { if (openSongs.isNotEmpty()) vm.playSong(openSongs.first(), openSongs) },
                    colors = ButtonDefaults.buttonColors(containerColor = c.accentPrimary)
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.Black)
                    Spacer(Modifier.width(4.dp))
                    Text("Play All", color = Color.Black, fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = {
                        if (openSongs.isNotEmpty()) {
                            val shuffled = openSongs.shuffled()
                            vm.playSong(shuffled.first(), shuffled)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = c.glassElevated)
                ) {
                    Icon(Icons.Rounded.Shuffle, contentDescription = null, tint = c.textPrimary)
                    Spacer(Modifier.width(4.dp))
                    Text("Shuffle", color = c.textPrimary)
                }
            }
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 170.dp)
            ) {
                itemsIndexed(openSongs, key = { _, s -> s.id }) { _, s ->
                    LiquidGlassBox(
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { vm.playSong(s, openSongs) }
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            MediaArtwork(model = s.customArtUri ?: s.albumArtUri, size = 44.dp)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(s.title, color = c.textPrimary, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(s.artist, color = c.textMuted, fontSize = 12.sp, maxLines = 1)
                            }
                            if (openPlaylistId != null) {
                                IconButton(onClick = {
                                    vm.removeSongFromPlaylist(openPlaylistId!!, s.id)
                                    openSongs = openSongs.filterNot { it.id == s.id }
                                }) {
                                    Icon(Icons.Rounded.Close, contentDescription = "Remove", tint = c.textMuted)
                                }
                            }
                        }
                    }
                }
            }
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 170.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("My Playlists", color = c.textPrimary, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            LiquidGlassBox(
                elevated = true,
                shape = RoundedCornerShape(50),
                modifier = Modifier.clickable { showCreate = true }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, tint = c.accentPrimary, modifier = Modifier.size(18.dp))
                    Text("New Playlist", color = c.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Smart Auto-Playlists
        PlaylistGlassCard("Favorites", "${favSongs.size} Liked Songs", Icons.Rounded.Favorite, c.danger) {
            openTitle = "Favorites"; openPlaylistId = null; openSongs = favSongs
        }
        PlaylistGlassCard("Most Played", "${mostPlayedSongs.size} Top Tracks", Icons.Rounded.GraphicEq, c.accentPrimary) {
            openTitle = "Most Played"; openPlaylistId = null; openSongs = mostPlayedSongs
        }
        PlaylistGlassCard("Never Played", "${neverPlayedSongs.size} Fresh Tracks", Icons.Rounded.MusicNote, c.accentSecondary) {
            openTitle = "Never Played"; openPlaylistId = null; openSongs = neverPlayedSongs
        }

        if (playlists.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Text("Custom Playlists", color = c.textSecondary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            playlists.forEach { pl ->
                val plSongs = refs.filter { it.playlistId == pl.id }.mapNotNull { songMap[it.songId] }
                PlaylistGlassCard(pl.name, "${plSongs.size} Songs", Icons.Rounded.QueueMusic, c.accentPrimary) {
                    openTitle = pl.name; openPlaylistId = pl.id; openSongs = plSongs
                }
            }
        }
    }

    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("Create Playlist") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    placeholder = { Text("Playlist name...") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    vm.createPlaylist(newName)
                    newName = ""
                    showCreate = false
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun PlaylistGlassCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    onClick: () -> Unit
) {
    val c = LocalAnruColors.current
    LiquidGlassBox(
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(tint.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = tint)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = c.textPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = c.textMuted, fontSize = 12.sp)
            }
            Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = c.textMuted)
        }
    }
}

@Composable
fun FloatingMiniPlayer(
    vm: AnruViewModel,
    onExpand: () -> Unit,
    modifier: Modifier = Modifier
) {
    val c = LocalAnruColors.current
    val song by vm.currentSong.collectAsState()
    val isPlaying by vm.isPlaying.collectAsState()
    val pos by vm.positionMs.collectAsState()
    val dur by vm.durationMs.collectAsState()

    val activeSong = song ?: return
    val progress = if (dur > 0) (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f) else 0f
    var dragAccumulator by remember { mutableFloatStateOf(0f) }

    LiquidGlassBox(
        elevated = true,
        shape = RoundedCornerShape(22.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
            .pointerInput(activeSong.id) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        if (dragAccumulator < -70f) vm.nextSong()
                        else if (dragAccumulator > 70f) vm.previousSong()
                        dragAccumulator = 0f
                    },
                    onHorizontalDrag = { _, dragAmount -> dragAccumulator += dragAmount }
                )
            }
            .clickable { onExpand() }
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.5.dp)
                    .background(Color.White.copy(alpha = 0.1f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress)
                        .height(2.5.dp)
                        .background(Brush.horizontalGradient(listOf(c.accentPrimary, c.accentSecondary)))
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MediaArtwork(model = activeSong.customArtUri ?: activeSong.albumArtUri, size = 44.dp, cornerRadius = 12.dp)
                Column(modifier = Modifier.weight(1f)) {
                    Text(activeSong.title, color = c.textPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(activeSong.artist, color = c.textMuted, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = vm::previousSong, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous", tint = c.textPrimary)
                }
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(c.accentPrimary, c.accentSecondary)))
                        .clickable { vm.togglePlayPause() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = "Play/Pause",
                        tint = Color.Black
                    )
                }
                IconButton(onClick = vm::nextSong, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Rounded.SkipNext, contentDescription = "Next", tint = c.textPrimary)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FullscreenMusicPlayer(
    visible: Boolean,
    vm: AnruViewModel,
    onDismiss: () -> Unit
) {
    val c = LocalAnruColors.current
    val song by vm.currentSong.collectAsState()
    val isPlaying by vm.isPlaying.collectAsState()
    val pos by vm.positionMs.collectAsState()
    val dur by vm.durationMs.collectAsState()
    val isShuffle by vm.isShuffle.collectAsState()
    val repeatMode by vm.repeatMode.collectAsState()
    val speed by vm.playbackSpeed.collectAsState()
    val favIds by vm.favoriteIds.collectAsState()
    val prefs by vm.userPrefs.collectAsState()
    val sleepSec by vm.sleepTimerRemainingSec.collectAsState()
    val queue by vm.queue.collectAsState()

    var showEq by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }

    AnimatedVisibility(
        visible = visible && song != null,
        enter = slideInVertically(
            initialOffsetY = { it },
            animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMediumLow)
        ) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
    ) {
        val activeSong = song ?: return@AnimatedVisibility
        val isFav = activeSong.id in favIds
        val artScale by animateFloatAsState(
            targetValue = if (isPlaying) 1.0f else 0.88f,
            animationSpec = OriginSpringFloat,
            label = "artScale"
        )
        val progress = if (dur > 0) (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f) else 0f

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 22.dp, vertical = 12.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    LiquidGlassBox(shape = CircleShape, modifier = Modifier.size(42.dp).clickable { onDismiss() }) {
                        Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Minimize", tint = c.textPrimary, modifier = Modifier.align(Alignment.Center))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("NOW PLAYING", color = c.accentPrimary, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
                        Text(activeSong.album, color = c.textSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LiquidGlassBox(shape = CircleShape, modifier = Modifier.size(40.dp).clickable { showEq = true }) {
                            Icon(Icons.Rounded.Equalizer, contentDescription = "EQ", tint = c.textPrimary, modifier = Modifier.align(Alignment.Center).size(20.dp))
                        }
                        LiquidGlassBox(shape = CircleShape, modifier = Modifier.size(40.dp).clickable { showSleep = true }) {
                            Icon(Icons.Rounded.Bedtime, contentDescription = "Sleep", tint = if (sleepSec > 0) c.accentPrimary else c.textPrimary, modifier = Modifier.align(Alignment.Center).size(20.dp))
                        }
                        LiquidGlassBox(shape = CircleShape, modifier = Modifier.size(40.dp).clickable { showQueue = true }) {
                            Icon(Icons.Rounded.QueueMusic, contentDescription = "Queue", tint = c.textPrimary, modifier = Modifier.align(Alignment.Center).size(20.dp))
                        }
                    }
                }

                // Floating Spring-Scaled Artwork
                Box(
                    modifier = Modifier
                        .size(276.dp)
                        .scale(artScale)
                        .clip(RoundedCornerShape(32.dp))
                        .border(1.5.dp, Brush.verticalGradient(listOf(c.glassBorderTop, c.glassBorderBottom)), RoundedCornerShape(32.dp))
                ) {
                    MediaArtwork(
                        model = activeSong.customArtUri ?: activeSong.albumArtUri,
                        size = 276.dp,
                        cornerRadius = 32.dp
                    )
                }

                // Title + Favorite
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(activeSong.title, color = c.textPrimary, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(activeSong.artist, color = c.textMuted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { vm.toggleFavorite(activeSong.id) }) {
                        Icon(
                            imageVector = if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (isFav) c.danger else c.textSecondary,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                // 3D Audio + Normalize Pills
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DspTogglePill("3D Audio", Icons.Rounded.Headphones, prefs.virtualizerOn) {
                        vm.applyDspUpdate(virtualizer = !prefs.virtualizerOn)
                    }
                    DspTogglePill("Normalize", Icons.Rounded.VolumeUp, prefs.normalizerOn) {
                        vm.applyDspUpdate(normalizer = !prefs.normalizerOn)
                    }
                    DspTogglePill("${speed}x", Icons.Rounded.GraphicEq, speed != 1.0f) {
                        vm.cyclePlaybackSpeed()
                    }
                }

                // Waveform + Slider
                Column(modifier = Modifier.fillMaxWidth()) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(34.dp)
                    ) {
                        val bars = 42
                        val gap = size.width / bars
                        val activeBars = (bars * progress).toInt()
                        for (i in 0 until bars) {
                            val amp = (0.28f + 0.65f * abs(sin((i + activeSong.id % 17) * 0.55f))).toFloat()
                            val h = size.height * amp
                            val top = (size.height - h) / 2f
                            drawRoundRect(
                                color = if (i <= activeBars) c.accentPrimary else Color.White.copy(alpha = 0.22f),
                                topLeft = Offset(i * gap + 2f, top),
                                size = Size(gap * 0.55f, h),
                                cornerRadius = CornerRadius(4f, 4f)
                            )
                        }
                    }
                    Slider(
                        value = progress,
                        onValueChange = { frac -> if (dur > 0) vm.seekTo((frac * dur).toLong()) },
                        colors = SliderDefaults.colors(
                            thumbColor = c.textPrimary,
                            activeTrackColor = c.accentPrimary,
                            inactiveTrackColor = Color.White.copy(alpha = 0.18f)
                        )
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(formatTimeMs(pos), color = c.textMuted, fontSize = 12.sp)
                        Text(formatTimeMs(dur), color = c.textMuted, fontSize = 12.sp)
                    }
                }

                // Transport Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = vm::toggleShuffle) {
                        Icon(Icons.Rounded.Shuffle, contentDescription = "Shuffle", tint = if (isShuffle) c.accentPrimary else c.textMuted)
                    }
                    IconButton(onClick = vm::previousSong, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Rounded.SkipPrevious, contentDescription = "Prev", tint = c.textPrimary, modifier = Modifier.size(34.dp))
                    }
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(c.accentPrimary, c.accentSecondary)))
                            .clickable { vm.togglePlayPause() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = Color.Black,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    IconButton(onClick = vm::nextSong, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Rounded.SkipNext, contentDescription = "Next", tint = c.textPrimary, modifier = Modifier.size(34.dp))
                    }
                    IconButton(onClick = vm::cycleRepeatMode) {
                        Icon(
                            imageVector = if (repeatMode == RepeatMode.ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                            contentDescription = "Repeat",
                            tint = if (repeatMode == RepeatMode.OFF) c.textMuted else c.accentPrimary
                        )
                    }
                }
            }
        }
    }

    // Native Equalizer & Bass Sheet
    if (showEq) {
        ModalBottomSheet(onDismissRequest = { showEq = false }, containerColor = c.bgTop) {
            val bands = prefs.eqBands
            val labels = listOf("60Hz", "230Hz", "910Hz", "3.6kHz", "14kHz")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Native Studio Equalizer", color = c.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                labels.forEachIndexed { idx, freq ->
                    val dbVal = bands.getOrElse(idx) { 0 }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(freq, color = c.textSecondary, fontSize = 12.sp, modifier = Modifier.width(52.dp))
                        Slider(
                            value = dbVal.toFloat(),
                            onValueChange = { v ->
                                val updated = bands.toMutableList()
                                while (updated.size <= idx) updated.add(0)
                                updated[idx] = v.toInt()
                                vm.applyDspUpdate(eqBands = updated)
                            },
                            valueRange = -12f..12f,
                            modifier = Modifier.weight(1f)
                        )
                        Text("${dbVal}dB", color = c.accentPrimary, fontSize = 12.sp, modifier = Modifier.width(42.dp))
                    }
                }
                Text("Extra Bass Boost (${prefs.bassBoostLevel / 10}%)", color = c.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Slider(
                    value = prefs.bassBoostLevel.toFloat(),
                    onValueChange = { vm.applyDspUpdate(bass = it.toInt()) },
                    valueRange = 0f..1000f
                )
                Text("Volume Booster (${100 + prefs.loudnessBoostMb / 10}%)", color = c.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Slider(
                    value = prefs.loudnessBoostMb.toFloat(),
                    onValueChange = { vm.applyDspUpdate(loudnessMb = it.toInt()) },
                    valueRange = 0f..1000f
                )
                Spacer(Modifier.height(10.dp))
            }
        }
    }

    // Sleep Timer Sheet
    if (showSleep) {
        ModalBottomSheet(onDismissRequest = { showSleep = false }, containerColor = c.bgTop) {
            Column(
                modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Sleep Timer", color = c.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                if (sleepSec > 0) {
                    Text("Remaining: ${sleepSec / 60}m ${sleepSec % 60}s", color = c.accentPrimary)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf(15, 30, 45, 60, 0).forEach { mins ->
                        LiquidGlassBox(
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f).clickable {
                                vm.setSleepTimerMinutes(mins)
                                showSleep = false
                            }
                        ) {
                            Text(
                                text = if (mins == 0) "Off" else "${mins}m",
                                color = if (mins == 0) c.danger else c.textPrimary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.Center).padding(vertical = 12.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
    }

    // Play Queue Sheet
    if (showQueue) {
        ModalBottomSheet(onDismissRequest = { showQueue = false }, containerColor = c.bgTop) {
            Column(modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp)) {
                Text("Play Queue (${queue.size})", color = c.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp))
                LazyColumn(
                    modifier = Modifier.height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    itemsIndexed(queue, key = { idx, s -> "${s.id}_$idx" }) { idx, s ->
                        val isCur = song?.id == s.id
                        LiquidGlassBox(
                            elevated = isCur,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().clickable { vm.playSong(s, queue) }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("${idx + 1}", color = if (isCur) c.accentPrimary else c.textMuted, fontSize = 12.sp)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(s.title, color = if (isCur) c.accentPrimary else c.textPrimary, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(s.artist, color = c.textMuted, fontSize = 11.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun DspTogglePill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean,
    onClick: () -> Unit
) {
    val c = LocalAnruColors.current
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (active) Brush.horizontalGradient(listOf(c.accentPrimary, c.accentSecondary)) else Brush.horizontalGradient(listOf(c.glassSurface, c.glassSurface)))
            .border(1.dp, if (active) Color.Transparent else c.glassBorderTop, RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, contentDescription = null, tint = if (active) Color.Black else c.textPrimary, modifier = Modifier.size(15.dp))
            Text(label, color = if (active) Color.Black else c.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}
