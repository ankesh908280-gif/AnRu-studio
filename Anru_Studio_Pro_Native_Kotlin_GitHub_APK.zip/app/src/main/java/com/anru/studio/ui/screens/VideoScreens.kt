package com.anru.studio.ui.screens

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.Audiotrack
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckBox
import androidx.compose.material.icons.rounded.CheckBoxOutlineBlank
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import com.anru.studio.R
import com.anru.studio.data.model.AudioTrackOption
import com.anru.studio.data.model.VideoItem
import com.anru.studio.data.model.VideoSort
import com.anru.studio.ui.AnruViewModel
import com.anru.studio.ui.components.GlassSearchBar
import com.anru.studio.ui.theme.LiquidGlassBox
import com.anru.studio.ui.theme.LocalAnruColors
import com.anru.studio.ui.theme.formatFileSize
import com.anru.studio.ui.theme.formatTimeMs
import kotlinx.coroutines.delay

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun VideosScreen(
    vm: AnruViewModel,
    onRequestDeleteUris: (List<Uri>) -> Unit
) {
    val c = LocalAnruColors.current
    val allVideos by vm.visibleVideos.collectAsState()
    val folders by vm.videoFolders.collectAsState()
    val query by vm.videoSearch.collectAsState()
    val sort by vm.videoSort.collectAsState()

    var showFoldersMode by remember { mutableStateOf(false) }
    var activeFolder by remember { mutableStateOf<String?>(null) }
    var sortExpanded by remember { mutableStateOf(false) }
    var isSelectMode by remember { mutableStateOf(false) }
    var selectedIds by remember { mutableStateOf(setOf<Long>()) }
    var actionVideo by remember { mutableStateOf<VideoItem?>(null) }
    var dismissContinue by remember { mutableStateOf(false) }

    val filteredVideos = remember(allVideos, query, sort, activeFolder) {
        val q = query.trim().lowercase()
        val list = allVideos.filter { v ->
            (activeFolder == null || v.folderName == activeFolder) &&
                (q.isEmpty() || v.title.lowercase().contains(q) || v.folderName.lowercase().contains(q))
        }
        when (sort) {
            VideoSort.DATE_NEW -> list.sortedByDescending { it.dateModifiedSec }
            VideoSort.TITLE_ASC -> list.sortedBy { it.title.lowercase() }
            VideoSort.SIZE_DESC -> list.sortedByDescending { it.sizeBytes }
            VideoSort.DURATION_DESC -> list.sortedByDescending { it.durationMs }
        }
    }

    val continueVideo = remember(allVideos) {
        allVideos.filter { it.lastPositionMs > 5_000L && (it.durationMs == 0L || it.lastPositionMs < it.durationMs - 5_000L) }
            .maxByOrNull { it.lastWatchedAt }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        GlassSearchBar(
            query = query,
            placeholder = "Search movies, videos, folders...",
            onQueryChange = vm::setVideoSearch
        )
        Spacer(Modifier.height(12.dp))

        // All Videos vs Folders Switcher
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SubTabChip(
                label = "All Videos (${allVideos.size})",
                active = !showFoldersMode,
                modifier = Modifier.weight(1f)
            ) {
                showFoldersMode = false
                activeFolder = null
            }
            SubTabChip(
                label = "Folders (${folders.size})",
                active = showFoldersMode,
                modifier = Modifier.weight(1f)
            ) {
                showFoldersMode = true
                activeFolder = null
                isSelectMode = false
                selectedIds = emptySet()
            }
        }
        Spacer(Modifier.height(10.dp))

        // Select + Sort Row (No 0 MB Copy badge!)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            LiquidGlassBox(
                shape = RoundedCornerShape(50),
                modifier = Modifier.clickable {
                    if (isSelectMode) {
                        isSelectMode = false
                        selectedIds = emptySet()
                    } else {
                        showFoldersMode = false
                        isSelectMode = true
                    }
                }
            ) {
                Text(
                    text = if (isSelectMode) "Cancel (${selectedIds.size})" else "Select",
                    color = if (isSelectMode) c.accentPrimary else c.textSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                )
            }

            Box {
                LiquidGlassBox(
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.clickable { sortExpanded = true }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Rounded.Sort, contentDescription = null, tint = c.accentPrimary, modifier = Modifier.size(15.dp))
                        Text(sort.label, color = c.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
                DropdownMenu(expanded = sortExpanded, onDismissRequest = { sortExpanded = false }) {
                    VideoSort.entries.forEach { s ->
                        DropdownMenuItem(
                            text = { Text(s.label) },
                            onClick = { vm.setVideoSort(s); sortExpanded = false }
                        )
                    }
                }
            }
        }

        AnimatedVisibility(visible = isSelectMode && selectedIds.isNotEmpty()) {
            LiquidGlassBox(
                elevated = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = {
                        selectedIds = if (selectedIds.size == filteredVideos.size) emptySet()
                        else filteredVideos.map { it.id }.toSet()
                    }) {
                        Text(if (selectedIds.size == filteredVideos.size) "Clear All" else "Select All", color = c.accentPrimary)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(onClick = {
                            selectedIds.forEach { vm.moveToVault(it, isVideo = true) }
                            isSelectMode = false
                            selectedIds = emptySet()
                        }) {
                            Icon(Icons.Rounded.Lock, contentDescription = "Move to Vault", tint = c.accentSecondary)
                        }
                        IconButton(onClick = {
                            val uris = filteredVideos.filter { it.id in selectedIds }.map { it.uri }
                            onRequestDeleteUris(uris)
                            isSelectMode = false
                            selectedIds = emptySet()
                        }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = c.danger)
                        }
                    }
                }
            }
        }

        if (activeFolder != null) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(onClick = { activeFolder = null }) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = c.textPrimary)
                }
                Text(activeFolder ?: "", color = c.textPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }

        // Continue Watching Card
        if (continueVideo != null && !dismissContinue && !showFoldersMode && activeFolder == null) {
            Spacer(Modifier.height(10.dp))
            LiquidGlassBox(
                elevated = true,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { vm.openVideo(continueVideo, filteredVideos) }
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    VideoThumbnailBox(continueVideo, widthDp = 88, heightDp = 54)
                    Column(modifier = Modifier.weight(1f)) {
                        Text("CONTINUE WATCHING", color = c.accentPrimary, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                        Text(continueVideo.title, color = c.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("Resume ${formatTimeMs(continueVideo.lastPositionMs)} / ${formatTimeMs(continueVideo.durationMs)}", color = c.textMuted, fontSize = 11.sp)
                    }
                    IconButton(onClick = { dismissContinue = true }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Dismiss", tint = c.textMuted, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        if (showFoldersMode && activeFolder == null) {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 170.dp)
            ) {
                items(folders, key = { it.name }) { folder ->
                    LiquidGlassBox(
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { activeFolder = folder.name }
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(13.dp))
                                    .background(c.accentPrimary.copy(alpha = 0.16f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Rounded.Folder, contentDescription = null, tint = c.accentPrimary)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(folder.name, color = c.textPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text("${folder.videoCount} Videos • ${formatFileSize(folder.totalSizeBytes)}", color = c.textMuted, fontSize = 12.sp)
                            }
                            IconButton(onClick = {
                                val uris = allVideos.filter { it.folderName == folder.name }.map { it.uri }
                                onRequestDeleteUris(uris)
                            }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Delete Folder Videos", tint = c.danger)
                            }
                        }
                    }
                }
            }
        } else if (filteredVideos.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.Movie, contentDescription = null, tint = c.textMuted, modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("No videos found on device", color = c.textSecondary, fontWeight = FontWeight.SemiBold)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(9.dp),
                contentPadding = PaddingValues(bottom = 170.dp)
            ) {
                items(filteredVideos, key = { it.id }) { vid ->
                    val isSel = vid.id in selectedIds
                    LiquidGlassBox(
                        elevated = isSel,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .combinedClickable(
                                onClick = {
                                    if (isSelectMode) {
                                        selectedIds = if (isSel) selectedIds - vid.id else selectedIds + vid.id
                                    } else {
                                        vm.openVideo(vid, filteredVideos)
                                    }
                                },
                                onLongClick = {
                                    isSelectMode = true
                                    selectedIds = selectedIds + vid.id
                                }
                            )
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            if (isSelectMode) {
                                Icon(
                                    imageVector = if (isSel) Icons.Rounded.CheckBox else Icons.Rounded.CheckBoxOutlineBlank,
                                    contentDescription = null,
                                    tint = if (isSel) c.accentPrimary else c.textMuted
                                )
                            }
                            VideoThumbnailBox(vid, widthDp = 108, heightDp = 64)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(vid.title, color = c.textPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "${vid.folderName} • ${formatFileSize(vid.sizeBytes)}",
                                    color = c.textMuted,
                                    fontSize = 11.5.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (vid.lastPositionMs > 3000L) {
                                    Text("Resume ${formatTimeMs(vid.lastPositionMs)}", color = c.accentPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                            if (!isSelectMode) {
                                IconButton(onClick = { actionVideo = vid }) {
                                    Icon(Icons.Rounded.MoreVert, contentDescription = "Options", tint = c.textMuted)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Video 3-Dots Action Sheet
    actionVideo?.let { vid ->
        ModalBottomSheet(onDismissRequest = { actionVideo = null }, containerColor = c.bgTop) {
            Column(
                modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(vid.title, color = c.textPrimary, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${vid.folderName} • ${formatFileSize(vid.sizeBytes)} • ${formatTimeMs(vid.durationMs)}", color = c.textMuted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                SheetOptionRow(Icons.Rounded.PlayArrow, "Play Video", c.textPrimary) {
                    vm.openVideo(vid, filteredVideos); actionVideo = null
                }
                SheetOptionRow(Icons.Rounded.Restore, "Reset Resume Position", c.textPrimary) {
                    vm.clearVideoProgress(vid.id); actionVideo = null
                }
                SheetOptionRow(Icons.Rounded.Lock, "Hide in Private Vault", c.accentSecondary) {
                    vm.moveToVault(vid.id, isVideo = true); actionVideo = null
                }
                SheetOptionRow(Icons.Rounded.Delete, "Delete from Phone", c.danger) {
                    onRequestDeleteUris(listOf(vid.uri)); actionVideo = null
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun SubTabChip(label: String, active: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = LocalAnruColors.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (active) Brush.horizontalGradient(listOf(c.accentPrimary, c.accentSecondary)) else Brush.horizontalGradient(listOf(c.glassSurface, c.glassSurface)))
            .border(1.dp, if (active) Color.Transparent else c.glassBorderTop, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (active) Color.Black else c.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun VideoThumbnailBox(vid: VideoItem, widthDp: Int, heightDp: Int) {
    val ctx = LocalContext.current
    val c = LocalAnruColors.current
    val pct = if (vid.durationMs > 0 && vid.lastPositionMs > 3000L) {
        (vid.lastPositionMs.toFloat() / vid.durationMs.toFloat()).coerceIn(0f, 0.98f)
    } else 0f

    Box(
        modifier = Modifier
            .width(widthDp.dp)
            .height(heightDp.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF141828))
    ) {
        AsyncImage(
            model = ImageRequest.Builder(ctx)
                .data(vid.uri)
                .videoFrameMillis(1500)
                .crossfade(true)
                .error(R.drawable.anru_logo)
                .build(),
            contentDescription = vid.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(4.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color.Black.copy(alpha = 0.72f))
                .padding(horizontal = 5.dp, vertical = 2.dp)
        ) {
            Text(formatTimeMs(vid.durationMs), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        if (pct > 0f) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(Color.White.copy(alpha = 0.25f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(pct)
                        .height(3.dp)
                        .background(c.accentPrimary)
                )
            }
        }
    }
}

/**
 * PLAYit-Style Native Fullscreen ExoPlayer Overlay with:
 * - True Native Picture-in-Picture (PiP)
 * - Dual Audio Track Selector + HW/SW Decoder Switch
 * - 200% Volume Booster (LoudnessEnhancer) + Swipe Brightness & Volume + Double-Tap ±10s Seek
 * - Screen Lock, Speed, Aspect Ratio, Landscape Rotate
 */
@OptIn(UnstableApi::class)
@Composable
fun PlayItVideoPlayerOverlay(
    video: VideoItem,
    queue: List<VideoItem>,
    vm: AnruViewModel,
    isInPipMode: Boolean,
    onEnterPip: () -> Unit,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val c = LocalAnruColors.current
    val prefs by vm.userPrefs.collectAsState()

    var currentVideo by remember(video.id) { mutableStateOf(video) }
    var isPlaying by remember { mutableStateOf(true) }
    var posMs by remember { mutableLongStateOf(video.lastPositionMs) }
    var durMs by remember { mutableLongStateOf(video.durationMs) }
    var showHud by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var boostPct by remember { mutableIntStateOf(100) } // 100, 150, 200
    var speedIdx by remember { mutableIntStateOf(1) }
    val speeds = listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
    var resizeMode by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var useSwDecoder by remember { mutableStateOf(prefs.preferSoftwareVideoDecoder) }
    var gestureHudText by remember { mutableStateOf<String?>(null) }
    var showAudioTrackDialog by remember { mutableStateOf(false) }
    var audioTracks by remember { mutableStateOf<List<AudioTrackOption>>(emptyList()) }

    var brightness by remember { mutableFloatStateOf(0.7f) }
    val audioManager = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    var loudnessEnhancer by remember { mutableStateOf<LoudnessEnhancer?>(null) }

    val exoPlayer = remember(useSwDecoder) {
        val renderersFactory = DefaultRenderersFactory(ctx).apply {
            setExtensionRendererMode(
                if (useSwDecoder) DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
                else DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF
            )
            setEnableDecoderFallback(true)
        }
        ExoPlayer.Builder(ctx, renderersFactory).build()
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                if (audioSessionId > 0) {
                    try { loudnessEnhancer?.release() } catch (_: Exception) {}
                    try { loudnessEnhancer = LoudnessEnhancer(audioSessionId) } catch (_: Exception) {}
                }
            }
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                val list = mutableListOf<AudioTrackOption>()
                tracks.groups.forEachIndexed { gIdx, group ->
                    if (group.type == C.TRACK_TYPE_AUDIO) {
                        for (tIdx in 0 until group.length) {
                            val fmt = group.getTrackFormat(tIdx)
                            val lang = fmt.language ?: "Track ${list.size + 1}"
                            val lbl = fmt.label ?: lang.uppercase()
                            list.add(AudioTrackOption(gIdx, tIdx, lbl, group.isTrackSelected(tIdx)))
                        }
                    }
                }
                audioTracks = list
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            vm.saveVideoProgress(currentVideo.id, exoPlayer.currentPosition)
            try { loudnessEnhancer?.release() } catch (_: Exception) {}
            exoPlayer.removeListener(listener)
            exoPlayer.release()
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    LaunchedEffect(currentVideo.id, exoPlayer) {
        exoPlayer.setMediaItem(MediaItem.fromUri(currentVideo.uri))
        exoPlayer.prepare()
        if (currentVideo.lastPositionMs > 3000L && (currentVideo.durationMs == 0L || currentVideo.lastPositionMs < currentVideo.durationMs - 4000L)) {
            exoPlayer.seekTo(currentVideo.lastPositionMs)
        }
        exoPlayer.playWhenReady = true
    }

    LaunchedEffect(boostPct, loudnessEnhancer) {
        try {
            loudnessEnhancer?.let { le ->
                val gainMb = ((boostPct - 100).coerceAtLeast(0)) * 10
                le.enabled = gainMb > 0
                if (gainMb > 0) le.setTargetGain(gainMb)
            }
        } catch (_: Exception) {}
    }

    LaunchedEffect(exoPlayer) {
        while (true) {
            posMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            val d = exoPlayer.duration
            if (d > 0) durMs = d
            if (exoPlayer.isPlaying && posMs > 3000L) {
                vm.saveVideoProgress(currentVideo.id, posMs)
            }
            delay(1000)
        }
    }

    LaunchedEffect(gestureHudText) {
        if (gestureHudText != null) {
            delay(900)
            gestureHudText = null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(isLocked, isInPipMode) {
                if (isInPipMode) return@pointerInput
                detectTapGestures(
                    onTap = { if (!isLocked) showHud = !showHud },
                    onDoubleTap = { offset ->
                        if (isLocked) return@detectTapGestures
                        if (offset.x < size.width * 0.4f) {
                            exoPlayer.seekTo((exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L))
                            gestureHudText = "⏪ -10s"
                        } else if (offset.x > size.width * 0.6f) {
                            exoPlayer.seekTo((exoPlayer.currentPosition + 10_000L).coerceAtMost(durMs.coerceAtLeast(1L)))
                            gestureHudText = "⏩ +10s"
                        } else {
                            if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                        }
                    }
                )
            }
            .pointerInput(isLocked, isInPipMode) {
                if (isInPipMode || isLocked) return@pointerInput
                detectVerticalDragGestures { change, dragAmount ->
                    val isLeft = change.position.x < size.width / 2f
                    if (isLeft) {
                        brightness = (brightness - dragAmount / 600f).coerceIn(0.05f, 1.0f)
                        activity?.window?.let { w ->
                            val lp = w.attributes
                            lp.screenBrightness = brightness
                            w.attributes = lp
                        }
                        gestureHudText = "☀ Brightness ${(brightness * 100).toInt()}%"
                    } else {
                        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                        val delta = if (dragAmount < -14f) 1 else if (dragAmount > 14f) -1 else 0
                        if (delta != 0) {
                            val next = (curVol + delta).coerceIn(0, maxVol)
                            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, next, 0)
                            gestureHudText = "🔊 Volume ${(next * 100 / maxVol)}%"
                        }
                    }
                }
            }
    ) {
        AndroidView(
            factory = { context ->
                PlayerView(context).apply {
                    useController = false
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { pv ->
                pv.player = exoPlayer
                pv.resizeMode = resizeMode
            },
            modifier = Modifier.fillMaxSize()
        )

        // Gesture Feedback Pill
        gestureHudText?.let { txt ->
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black.copy(alpha = 0.72f))
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(txt, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }

        // Unlock button when locked
        if (isLocked && !isInPipMode) {
            LiquidGlassBox(
                elevated = true,
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 18.dp)
                    .clickable { isLocked = false; showHud = true }
            ) {
                Row(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Rounded.LockOpen, contentDescription = "Unlock", tint = c.accentPrimary)
                    Text("Unlock", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // Player HUD (Hidden automatically in PiP mode or when locked)
        AnimatedVisibility(
            visible = showHud && !isLocked && !isInPipMode,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.36f))
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(14.dp)
            ) {
                // Top Bar
                Row(
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        IconButton(onClick = {
                            vm.saveVideoProgress(currentVideo.id, exoPlayer.currentPosition)
                            onClose()
                        }) {
                            Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(currentVideo.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(if (useSwDecoder) "SW Decoder" else "HW Decoder", color = c.accentPrimary, fontSize = 11.sp)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(onClick = {
                            boostPct = when (boostPct) { 100 -> 150; 150 -> 200; else -> 100 }
                            gestureHudText = "⚡ Volume Boost $boostPct%"
                        }) {
                            Icon(Icons.Rounded.Bolt, contentDescription = "200% Boost", tint = if (boostPct > 100) c.accentPrimary else Color.White)
                        }
                        IconButton(onClick = { showAudioTrackDialog = true }) {
                            Icon(Icons.Rounded.Audiotrack, contentDescription = "Audio Track", tint = Color.White)
                        }
                        IconButton(onClick = onEnterPip) {
                            Icon(Icons.Rounded.PictureInPictureAlt, contentDescription = "PiP", tint = Color.White)
                        }
                    }
                }

                // Center Transport Controls
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        val idx = queue.indexOfFirst { it.id == currentVideo.id }
                        if (idx > 0) currentVideo = queue[idx - 1]
                    }) {
                        Icon(Icons.Rounded.SkipPrevious, contentDescription = "Prev", tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                    IconButton(onClick = {
                        exoPlayer.seekTo((exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L))
                    }) {
                        Icon(Icons.Rounded.Replay10, contentDescription = "-10s", tint = Color.White, modifier = Modifier.size(34.dp))
                    }
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(c.accentPrimary, c.accentSecondary)))
                            .clickable { if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = Color.Black,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    IconButton(onClick = {
                        exoPlayer.seekTo((exoPlayer.currentPosition + 10_000L).coerceAtMost(durMs.coerceAtLeast(1L)))
                    }) {
                        Icon(Icons.Rounded.Forward10, contentDescription = "+10s", tint = Color.White, modifier = Modifier.size(34.dp))
                    }
                    IconButton(onClick = {
                        val idx = queue.indexOfFirst { it.id == currentVideo.id }
                        if (idx in 0 until queue.lastIndex) currentVideo = queue[idx + 1]
                    }) {
                        Icon(Icons.Rounded.SkipNext, contentDescription = "Next", tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                }

                // Bottom Timeline & Utility Dock
                Column(modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter)) {
                    val progress = if (durMs > 0) (posMs.toFloat() / durMs.toFloat()).coerceIn(0f, 1f) else 0f
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(formatTimeMs(posMs), color = Color.White, fontSize = 11.sp)
                        Slider(
                            value = progress,
                            onValueChange = { f -> if (durMs > 0) exoPlayer.seekTo((f * durMs).toLong()) },
                            modifier = Modifier.weight(1f),
                            colors = SliderDefaults.colors(thumbColor = c.accentPrimary, activeTrackColor = c.accentPrimary)
                        )
                        Text(formatTimeMs(durMs), color = Color.White, fontSize = 11.sp)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        HudUtilAction(Icons.Rounded.Lock, "Lock") { isLocked = true; showHud = false }
                        HudUtilAction(Icons.Rounded.Speed, "${speeds[speedIdx]}x") {
                            speedIdx = (speedIdx + 1) % speeds.size
                            exoPlayer.setPlaybackSpeed(speeds[speedIdx])
                        }
                        HudUtilAction(Icons.Rounded.Tune, if (useSwDecoder) "SW" else "HW") {
                            useSwDecoder = !useSwDecoder
                            gestureHudText = if (useSwDecoder) "Switched to Software Decoder" else "Switched to Hardware Decoder"
                        }
                        HudUtilAction(Icons.Rounded.AspectRatio, "Ratio") {
                            resizeMode = when (resizeMode) {
                                AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                            }
                        }
                        HudUtilAction(Icons.Rounded.ScreenRotation, "Rotate") {
                            activity?.let { act ->
                                val isLand = act.requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                act.requestedOrientation = if (isLand) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            }
                        }
                    }
                }
            }
        }
    }

    // Dual Audio Track Picker Dialog
    if (showAudioTrackDialog) {
        AlertDialog(
            onDismissRequest = { showAudioTrackDialog = false },
            title = { Text("Select Audio Track") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (audioTracks.isEmpty()) {
                        Text("Single default audio track detected.")
                    } else {
                        audioTracks.forEach { tr ->
                            LiquidGlassBox(
                                elevated = tr.isSelected,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        val group = exoPlayer.currentTracks.groups.getOrNull(tr.groupIndex)
                                        if (group != null) {
                                            val params = exoPlayer.trackSelectionParameters.buildUpon()
                                                .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, tr.trackIndex))
                                                .build()
                                            exoPlayer.trackSelectionParameters = params
                                            gestureHudText = "Audio Track: ${tr.label}"
                                        }
                                        showAudioTrackDialog = false
                                    }
                            ) {
                                Text(
                                    text = if (tr.isSelected) "✓ ${tr.label}" else tr.label,
                                    color = if (tr.isSelected) c.accentPrimary else c.textPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showAudioTrackDialog = false }) { Text("Close") } }
        )
    }
}

@Composable
private fun HudUtilAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(20.dp))
        Text(label, color = Color.White.copy(alpha = 0.85f), fontSize = 10.sp)
    }
}
