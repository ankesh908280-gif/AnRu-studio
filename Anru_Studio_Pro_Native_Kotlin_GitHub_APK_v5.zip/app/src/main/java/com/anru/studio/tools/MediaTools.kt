package com.anru.studio.tools

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.anru.studio.data.db.AnruDao
import com.anru.studio.data.db.FavoriteEntity
import com.anru.studio.data.db.PlayHistoryEntity
import com.anru.studio.data.db.PlaylistEntity
import com.anru.studio.data.db.PlaylistSongCrossRef
import com.anru.studio.data.db.TagOverrideEntity
import com.anru.studio.data.db.VaultItemEntity
import com.anru.studio.data.model.DuplicateEntry
import com.anru.studio.data.model.DuplicateGroup
import com.anru.studio.data.model.SongItem
import com.anru.studio.data.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer

object DuplicateScanner {
    fun findDuplicates(songs: List<SongItem>, videos: List<VideoItem>): List<DuplicateGroup> {
        val groups = mutableListOf<DuplicateGroup>()

        // Duplicate songs by exact size + normalized title
        songs.filter { it.sizeBytes > 0 }
            .groupBy { "${it.sizeBytes}|${it.title.trim().lowercase()}" }
            .filter { it.value.size > 1 }
            .forEach { (key, list) ->
                groups.add(
                    DuplicateGroup(
                        key = "song_$key",
                        isVideo = false,
                        sizeBytes = list.first().sizeBytes,
                        items = list.map {
                            DuplicateEntry(it.id, it.uri, it.title, it.folderName, it.sizeBytes)
                        }
                    )
                )
            }

        // Duplicate videos by exact size
        videos.filter { it.sizeBytes > 0 }
            .groupBy { "${it.sizeBytes}|${it.durationMs / 1000}" }
            .filter { it.value.size > 1 }
            .forEach { (key, list) ->
                groups.add(
                    DuplicateGroup(
                        key = "vid_$key",
                        isVideo = true,
                        sizeBytes = list.first().sizeBytes,
                        items = list.map {
                            DuplicateEntry(it.id, it.uri, it.title, it.folderName, it.sizeBytes)
                        }
                    )
                )
            }

        return groups.sortedByDescending { it.sizeBytes * it.items.size }
    }
}

object RingtoneTrimmer {

    suspend fun trimAndSaveRingtone(
        context: Context,
        sourceUri: Uri,
        outputTitle: String,
        startMs: Long,
        endMs: Long,
        setAsDefaultRingtone: Boolean
    ): Result<Uri> = withContext(Dispatchers.IO) {
        val tempOut = File(context.cacheDir, "anru_ringtone_${System.currentTimeMillis()}.m4a")
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            extractor.setDataSource(context, sourceUri, null)
            var audioTrackIndex = -1
            var trackFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    trackFormat = fmt
                    break
                }
            }
            if (audioTrackIndex < 0 || trackFormat == null) {
                return@withContext Result.failure(IllegalStateException("No audio track found"))
            }

            extractor.selectTrack(audioTrackIndex)
            val startUs = (startMs.coerceAtLeast(0L)) * 1000L
            val endUs = (endMs.coerceAtLeast(startMs + 1000L)) * 1000L
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            muxer = MediaMuxer(tempOut.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxTrackIdx = muxer.addTrack(trackFormat)
            muxer.start()

            val buffer = ByteBuffer.allocate(256 * 1024)
            val info = MediaCodec.BufferInfo()
            var firstSampleUs = -1L

            while (true) {
                info.offset = 0
                info.size = extractor.readSampleData(buffer, 0)
                if (info.size < 0) break
                val sampleTimeUs = extractor.sampleTime
                if (sampleTimeUs > endUs) break
                if (firstSampleUs < 0L) firstSampleUs = sampleTimeUs
                info.presentationTimeUs = (sampleTimeUs - firstSampleUs).coerceAtLeast(0L)
                info.flags = extractor.sampleFlags
                muxer.writeSampleData(muxTrackIdx, buffer, info)
                extractor.advance()
            }

            muxer.stop()
            muxer.release()
            muxer = null
            extractor.release()

            val safeName = outputTitle.replace(Regex("[^a-zA-Z0-9_ -]"), "").trim().ifEmpty { "Anru_Ringtone" }
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, "${safeName}_cut.m4a")
                put(MediaStore.Audio.Media.TITLE, "$safeName (Anru Cut)")
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                put(MediaStore.Audio.Media.IS_RINGTONE, true)
                put(MediaStore.Audio.Media.IS_MUSIC, true)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_RINGTONES + "/AnruStudio")
                    put(MediaStore.Audio.Media.IS_PENDING, 1)
                }
            }

            val uri = context.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: return@withContext Result.failure(IllegalStateException("Could not create ringtone file"))

            context.contentResolver.openOutputStream(uri)?.use { outStream ->
                tempOut.inputStream().use { inStream -> inStream.copyTo(outStream) }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val doneVals = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
                context.contentResolver.update(uri, doneVals, null, null)
            }

            if (setAsDefaultRingtone && Settings.System.canWrite(context)) {
                RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_RINGTONE, uri)
            }

            tempOut.delete()
            Result.success(uri)
        } catch (e: Exception) {
            try { muxer?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
            tempOut.delete()
            Result.failure(e)
        }
    }
}

object VaultAuthHelper {
    fun canUseBiometrics(context: Context): Boolean {
        val bm = BiometricManager.from(context)
        val res = bm.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
        )
        return res == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun authenticateBiometric(
        activity: FragmentActivity,
        onSuccess: () -> Unit,
        onFallbackPin: () -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onFallbackPin()
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Anru Private Vault")
            .setSubtitle("Use fingerprint or face to view private media")
            .setNegativeButtonText("Use PIN")
            .build()
        prompt.authenticate(info)
    }
}

object BackupManager {

    suspend fun exportJson(dao: AnruDao): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("version", 28)
        root.put("exportedAt", System.currentTimeMillis())

        val pls = JSONArray()
        dao.getAllPlaylistsOnce().forEach { p ->
            pls.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("createdAt", p.createdAt)
            })
        }
        root.put("playlists", pls)

        val refs = JSONArray()
        dao.getAllPlaylistRefsOnce().forEach { r ->
            refs.put(JSONObject().apply {
                put("playlistId", r.playlistId)
                put("songId", r.songId)
                put("addedAt", r.addedAt)
            })
        }
        root.put("playlistRefs", refs)

        val favs = JSONArray()
        dao.getAllFavoritesOnce().forEach { f ->
            favs.put(JSONObject().apply {
                put("songId", f.songId)
                put("addedAt", f.addedAt)
            })
        }
        root.put("favorites", favs)

        val tags = JSONArray()
        dao.getAllTagOverridesOnce().forEach { t ->
            tags.put(JSONObject().apply {
                put("songId", t.songId)
                put("title", t.title)
                put("artist", t.artist)
                put("album", t.album)
                put("customArtUri", t.customArtUri ?: "")
            })
        }
        root.put("tagOverrides", tags)

        val vault = JSONArray()
        dao.getAllVaultItemsOnce().forEach { v ->
            vault.put(JSONObject().apply {
                put("key", v.itemKey)
                put("mediaId", v.mediaId)
                put("isVideo", v.isVideo)
                put("addedAt", v.addedAt)
            })
        }
        root.put("vaultItems", vault)

        val hist = JSONArray()
        dao.getAllPlayHistoryOnce().take(1500).forEach { h ->
            hist.put(JSONObject().apply {
                put("songId", h.songId)
                put("title", h.title)
                put("artist", h.artist)
                put("durationSec", h.durationSec)
                put("timestamp", h.timestamp)
            })
        }
        root.put("playHistory", hist)

        root.toString(2)
    }

    suspend fun importJson(dao: AnruDao, jsonText: String): Int = withContext(Dispatchers.IO) {
        val root = JSONObject(jsonText)
        var restored = 0

        val idMap = mutableMapOf<Long, Long>()
        root.optJSONArray("playlists")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val oldId = o.optLong("id")
                val newId = dao.insertPlaylist(
                    PlaylistEntity(
                        name = o.optString("name", "Playlist"),
                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    )
                )
                idMap[oldId] = newId
                restored++
            }
        }

        root.optJSONArray("playlistRefs")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val mappedPl = idMap[o.optLong("playlistId")] ?: continue
                dao.addSongToPlaylist(
                    PlaylistSongCrossRef(
                        playlistId = mappedPl,
                        songId = o.optLong("songId"),
                        addedAt = o.optLong("addedAt", System.currentTimeMillis())
                    )
                )
            }
        }

        root.optJSONArray("favorites")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                dao.addFavorite(FavoriteEntity(o.optLong("songId"), o.optLong("addedAt", System.currentTimeMillis())))
                restored++
            }
        }

        root.optJSONArray("tagOverrides")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                dao.upsertTagOverride(
                    TagOverrideEntity(
                        songId = o.optLong("songId"),
                        title = o.optString("title"),
                        artist = o.optString("artist"),
                        album = o.optString("album"),
                        customArtUri = o.optString("customArtUri").takeIf { it.isNotBlank() }
                    )
                )
                restored++
            }
        }

        root.optJSONArray("vaultItems")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                dao.addToVault(
                    VaultItemEntity(
                        itemKey = o.optString("key"),
                        mediaId = o.optLong("mediaId"),
                        isVideo = o.optBoolean("isVideo"),
                        addedAt = o.optLong("addedAt", System.currentTimeMillis())
                    )
                )
                restored++
            }
        }

        root.optJSONArray("playHistory")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                dao.insertPlayHistory(
                    PlayHistoryEntity(
                        songId = o.optLong("songId"),
                        title = o.optString("title"),
                        artist = o.optString("artist"),
                        durationSec = o.optInt("durationSec", 30),
                        timestamp = o.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }
        }

        restored
    }
}
