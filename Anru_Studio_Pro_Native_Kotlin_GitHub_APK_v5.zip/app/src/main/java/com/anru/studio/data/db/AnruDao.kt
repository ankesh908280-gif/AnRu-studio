package com.anru.studio.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AnruDao {

    // Playlists
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun observePlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    suspend fun getAllPlaylistsOnce(): List<PlaylistEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylist(playlistId: Long)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId")
    suspend fun clearPlaylistSongs(playlistId: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addSongToPlaylist(ref: PlaylistSongCrossRef)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long)

    @Query("SELECT * FROM playlist_songs ORDER BY addedAt ASC")
    fun observeAllPlaylistRefs(): Flow<List<PlaylistSongCrossRef>>

    @Query("SELECT * FROM playlist_songs")
    suspend fun getAllPlaylistRefsOnce(): List<PlaylistSongCrossRef>

    // Favorites
    @Query("SELECT songId FROM favorites")
    fun observeFavoriteIds(): Flow<List<Long>>

    @Query("SELECT * FROM favorites")
    suspend fun getAllFavoritesOnce(): List<FavoriteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(fav: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE songId = :songId")
    suspend fun removeFavorite(songId: Long)

    // Play History
    @Insert
    suspend fun insertPlayHistory(entry: PlayHistoryEntity)

    @Query("SELECT * FROM play_history ORDER BY timestamp DESC")
    fun observePlayHistory(): Flow<List<PlayHistoryEntity>>

    @Query("SELECT * FROM play_history")
    suspend fun getAllPlayHistoryOnce(): List<PlayHistoryEntity>

    // Video Progress
    @Query("SELECT * FROM video_progress")
    fun observeVideoProgress(): Flow<List<VideoProgressEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertVideoProgress(progress: VideoProgressEntity)

    @Query("DELETE FROM video_progress WHERE videoId = :videoId")
    suspend fun clearVideoProgress(videoId: Long)

    // Tag Overrides
    @Query("SELECT * FROM tag_overrides")
    fun observeTagOverrides(): Flow<List<TagOverrideEntity>>

    @Query("SELECT * FROM tag_overrides")
    suspend fun getAllTagOverridesOnce(): List<TagOverrideEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTagOverride(tag: TagOverrideEntity)

    // Private Vault
    @Query("SELECT * FROM vault_items ORDER BY addedAt DESC")
    fun observeVaultItems(): Flow<List<VaultItemEntity>>

    @Query("SELECT * FROM vault_items")
    suspend fun getAllVaultItemsOnce(): List<VaultItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addToVault(item: VaultItemEntity)

    @Query("DELETE FROM vault_items WHERE itemKey = :itemKey")
    suspend fun removeFromVault(itemKey: String)

    // Hidden Folders (Blacklist)
    @Query("SELECT folderName FROM hidden_folders")
    fun observeHiddenFolders(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun hideFolder(folder: HiddenFolderEntity)

    @Query("DELETE FROM hidden_folders WHERE folderName = :folderName")
    suspend fun unhideFolder(folderName: String)
}
