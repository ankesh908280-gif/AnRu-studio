package com.anru.studio.data.model

import android.net.Uri

enum class AppThemeMode(val key: String, val label: String) {
    ORIGIN_GLASS("origin_glass", "Origin Glass"),
    CYBER("cyber", "Cyber")
}

enum class MainTab { LIBRARY, PLAYLISTS, VIDEOS, STUDIO }

enum class SongSort(val label: String) {
    DATE_NEW("Newest"),
    TITLE_ASC("Title A-Z"),
    ARTIST_ASC("Artist A-Z"),
    DURATION_DESC("Longest")
}

enum class VideoSort(val label: String) {
    DATE_NEW("Recent"),
    TITLE_ASC("Name A-Z"),
    SIZE_DESC("Largest"),
    DURATION_DESC("Longest")
}

enum class RepeatMode { ALL, ONE, OFF }

data class SongItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val albumArtUri: Uri?,
    val customArtUri: String? = null,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateAddedSec: Long,
    val folderName: String,
    val relativePath: String,
    val displayName: String
)

data class VideoItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val displayName: String,
    val folderName: String,
    val relativePath: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateModifiedSec: Long,
    val width: Int,
    val height: Int,
    val lastPositionMs: Long = 0L,
    val lastWatchedAt: Long = 0L
)

data class VideoFolder(
    val name: String,
    val videoCount: Int,
    val totalSizeBytes: Long
)

data class AudioTrackOption(
    val groupIndex: Int,
    val trackIndex: Int,
    val label: String,
    val isSelected: Boolean
)

data class DuplicateGroup(
    val key: String,
    val isVideo: Boolean,
    val sizeBytes: Long,
    val items: List<DuplicateEntry>
)

data class DuplicateEntry(
    val mediaId: Long,
    val uri: Uri,
    val title: String,
    val folderName: String,
    val sizeBytes: Long
)

data class ListeningDayStat(
    val label: String,
    val minutes: Int
)

data class TopSongStat(
    val songId: Long,
    val title: String,
    val artist: String,
    val playCount: Int
)
