package com.anru.studio.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_songs", primaryKeys = ["playlistId", "songId"])
data class PlaylistSongCrossRef(
    val playlistId: Long,
    val songId: Long,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val songId: Long,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "play_history")
data class PlayHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val songId: Long,
    val title: String,
    val artist: String,
    val durationSec: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "video_progress")
data class VideoProgressEntity(
    @PrimaryKey val videoId: Long,
    val lastPositionMs: Long,
    val lastWatchedAt: Long
)

@Entity(tableName = "tag_overrides")
data class TagOverrideEntity(
    @PrimaryKey val songId: Long,
    val title: String,
    val artist: String,
    val album: String,
    val customArtUri: String? = null
)

@Entity(tableName = "vault_items")
data class VaultItemEntity(
    @PrimaryKey val itemKey: String, // "song_<id>" or "video_<id>"
    val mediaId: Long,
    val isVideo: Boolean,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "hidden_folders")
data class HiddenFolderEntity(
    @PrimaryKey val folderName: String
)
