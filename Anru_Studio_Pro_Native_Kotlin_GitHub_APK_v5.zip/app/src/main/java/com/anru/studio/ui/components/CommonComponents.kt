package com.anru.studio.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.anru.studio.R
import com.anru.studio.data.model.SongItem
import com.anru.studio.tools.SongArtModel
import com.anru.studio.ui.theme.LiquidGlassBox
import com.anru.studio.ui.theme.LocalAnruColors

@Composable
fun FrostedDockBox(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val c = LocalAnruColors.current
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(
                        c.bgTop.copy(alpha = 0.96f),
                        c.bgBottom.copy(alpha = 0.98f)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(listOf(c.glassBorderTop, c.glassBorderBottom)),
                shape = shape
            ),
        content = content
    )
}

@Composable
fun GlassSearchBar(
    query: String,
    placeholder: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val c = LocalAnruColors.current
    LiquidGlassBox(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.Search,
                contentDescription = "Search",
                tint = c.textMuted,
                modifier = Modifier.size(20.dp)
            )
            Box(modifier = Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text(
                        text = placeholder,
                        color = c.textMuted,
                        fontSize = 14.sp
                    )
                }
                BasicTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    singleLine = true,
                    textStyle = TextStyle(color = c.textPrimary, fontSize = 14.sp),
                    cursorBrush = SolidColor(c.accentPrimary),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (query.isNotEmpty()) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Clear",
                    tint = c.textMuted,
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .clickable { onQueryChange("") }
                )
            }
        }
    }
}

/**
 * Loads each song's OWN embedded MP3/FLAC/M4A cover art (never wrong shared album poster!)
 */
@Composable
fun SongArtwork(
    song: SongItem,
    size: Dp = 50.dp,
    cornerRadius: Dp = 14.dp,
    modifier: Modifier = Modifier
) {
    val data: Any = if (!song.customArtUri.isNullOrBlank()) {
        song.customArtUri
    } else {
        SongArtModel(songUri = song.uri, customArtPath = null)
    }
    MediaArtwork(model = data, size = size, cornerRadius = cornerRadius, modifier = modifier)
}

@Composable
fun MediaArtwork(
    model: Any?,
    size: Dp = 50.dp,
    cornerRadius: Dp = 14.dp,
    modifier: Modifier = Modifier
) {
    val ctx = LocalContext.current
    AsyncImage(
        model = ImageRequest.Builder(ctx)
            .data(model ?: R.drawable.anru_logo)
            .crossfade(true)
            .error(R.drawable.anru_logo)
            .placeholder(R.drawable.anru_logo)
            .build(),
        error = painterResource(R.drawable.anru_logo),
        placeholder = painterResource(R.drawable.anru_logo),
        contentDescription = "Artwork",
        contentScale = ContentScale.Crop,
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(cornerRadius))
    )
}

@Composable
fun AnimatedEqBars(
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    val c = LocalAnruColors.current
    val inf = rememberInfiniteTransition(label = "eqBars")
    val b1 by inf.animateFloat(
        initialValue = 0.25f, targetValue = 1.0f,
        animationSpec = infiniteRepeatable(tween(420, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b1"
    )
    val b2 by inf.animateFloat(
        initialValue = 0.95f, targetValue = 0.20f,
        animationSpec = infiniteRepeatable(tween(520, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b2"
    )
    val b3 by inf.animateFloat(
        initialValue = 0.35f, targetValue = 0.90f,
        animationSpec = infiniteRepeatable(tween(360, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b3"
    )

    val heights = if (isPlaying) listOf(b1, b2, b3) else listOf(0.28f, 0.45f, 0.28f)
    Row(
        modifier = modifier.height(16.dp),
        horizontalArrangement = Arrangement.spacedBy(2.5.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        heights.forEach { frac ->
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .fillMaxHeight(frac)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Brush.verticalGradient(listOf(c.accentPrimary, c.accentSecondary)))
            )
        }
    }
}
