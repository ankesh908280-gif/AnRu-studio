package com.anru.studio.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PlaylistEntity::class,
        PlaylistSongCrossRef::class,
        FavoriteEntity::class,
        PlayHistoryEntity::class,
        VideoProgressEntity::class,
        TagOverrideEntity::class,
        VaultItemEntity::class,
        HiddenFolderEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AnruDatabase : RoomDatabase() {
    abstract fun dao(): AnruDao

    companion object {
        @Volatile
        private var INSTANCE: AnruDatabase? = null

        fun getInstance(context: Context): AnruDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AnruDatabase::class.java,
                    "anru_studio_native_v28.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
        }
    }
}
