package com.anru.studio.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.anru.studio.data.model.AppThemeMode

@Immutable
data class AnruColors(
    val bgTop: Color,
    val bgBottom: Color,
    val orbPrimary: Color,
    val orbSecondary: Color,
    val glassSurface: Color,
    val glassElevated: Color,
    val glassBorderTop: Color,
    val glassBorderBottom: Color,
    val accentPrimary: Color,
    val accentSecondary: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val danger: Color,
    val success: Color
)

val OriginGlassPalette = AnruColors(
    bgTop = Color(0xFF0A0F1E),
    bgBottom = Color(0xFF05070E),
    orbPrimary = Color(0xFF3B82F6),
    orbSecondary = Color(0xFF8B5CF6),
    glassSurface = Color(0x1EFFFFFF),
    glassElevated = Color(0x2BFFFFFF),
    glassBorderTop = Color(0x4DFFFFFF),
    glassBorderBottom = Color(0x14FFFFFF),
    accentPrimary = Color(0xFF38BDF8),
    accentSecondary = Color(0xFFA78BFA),
    textPrimary = Color(0xFFF8FAFC),
    textSecondary = Color(0xFFCBD5E1),
    textMuted = Color(0xFF94A3B8),
    danger = Color(0xFFF87171),
    success = Color(0xFF34D399)
)

val CyberPalette = AnruColors(
    bgTop = Color(0xFF090418),
    bgBottom = Color(0xFF04020B),
    orbPrimary = Color(0xFF00F2FE),
    orbSecondary = Color(0xFFEC4899),
    glassSurface = Color(0x1F1E1038),
    glassElevated = Color(0x332D1654),
    glassBorderTop = Color(0x6600F2FE),
    glassBorderBottom = Color(0x33EC4899),
    accentPrimary = Color(0xFF00F2FE),
    accentSecondary = Color(0xFFEC4899),
    textPrimary = Color(0xFFFFFFFF),
    textSecondary = Color(0xFFE2D9F3),
    textMuted = Color(0xFFA799C4),
    danger = Color(0xFFFF4D6D),
    success = Color(0xFF10B981)
)

val LocalAnruColors = staticCompositionLocalOf { OriginGlassPalette }

val OriginSpringFloat = spring<Float>(
    dampingRatio = Spring.DampingRatioMediumBouncy,
    stiffness = Spring.StiffnessMediumLow
)

@Composable
fun AnruStudioTheme(
    themeMode: AppThemeMode,
    content: @Composable () -> Unit
) {
    val target = if (themeMode == AppThemeMode.CYBER) CyberPalette else OriginGlassPalette
    val animSpec = tween<Color>(durationMillis = 480, easing = FastOutSlowInEasing)

    val colors = AnruColors(
        bgTop = animateColorAsState(target.bgTop, animSpec, label = "bgTop").value,
        bgBottom = animateColorAsState(target.bgBottom, animSpec, label = "bgBottom").value,
        orbPrimary = animateColorAsState(target.orbPrimary, animSpec, label = "orb1").value,
        orbSecondary = animateColorAsState(target.orbSecondary, animSpec, label = "orb2").value,
        glassSurface = animateColorAsState(target.glassSurface, animSpec, label = "glass").value,
        glassElevated = animateColorAsState(target.glassElevated, animSpec, label = "glassEl").value,
        glassBorderTop = animateColorAsState(target.glassBorderTop, animSpec, label = "bTop").value,
        glassBorderBottom = animateColorAsState(target.glassBorderBottom, animSpec, label = "bBot").value,
        accentPrimary = animateColorAsState(target.accentPrimary, animSpec, label = "acc1").value,
        accentSecondary = animateColorAsState(target.accentSecondary, animSpec, label = "acc2").value,
        textPrimary = target.textPrimary,
        textSecondary = target.textSecondary,
        textMuted = target.textMuted,
        danger = target.danger,
        success = target.success
    )

    val m3Scheme = darkColorScheme(
        primary = colors.accentPrimary,
        secondary = colors.accentSecondary,
        background = colors.bgBottom,
        surface = colors.bgTop,
        onPrimary = Color.Black,
        onBackground = colors.textPrimary,
        onSurface = colors.textPrimary,
        error = colors.danger
    )

    CompositionLocalProvider(LocalAnruColors provides colors) {
        MaterialTheme(
            colorScheme = m3Scheme,
            content = content
        )
    }
}

/**
 * Silky iOS / OriginOS 7 Ambient Liquid Mesh Background with gently drifting glow orbs
 */
@Composable
fun AnimatedStudioBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val c = LocalAnruColors.current
    val infinite = rememberInfiniteTransition(label = "ambientOrbs")
    val drift1 by infinite.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(14000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "drift1"
    )
    val drift2 by infinite.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(17000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "drift2"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(c.orbPrimary.copy(alpha = 0.24f), Color.Transparent),
                    center = Offset(size.width * drift1, size.height * 0.14f),
                    radius = size.width * 0.85f
                ),
                radius = size.width * 0.85f,
                center = Offset(size.width * drift1, size.height * 0.14f)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(c.orbSecondary.copy(alpha = 0.20f), Color.Transparent),
                    center = Offset(size.width * drift2, size.height * 0.78f),
                    radius = size.width * 0.80f
                ),
                radius = size.width * 0.80f,
                center = Offset(size.width * drift2, size.height * 0.78f)
            )
        }
        content()
    }
}

/**
 * Liquid Glass Card with Specular Top-Light Border (iOS / OriginOS 7 aesthetic)
 */
@Composable
fun LiquidGlassBox(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(22.dp),
    elevated: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val c = LocalAnruColors.current
    val fill = if (elevated) c.glassElevated else c.glassSurface
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(fill.copy(alpha = fill.alpha * 1.15f), fill.copy(alpha = fill.alpha * 0.72f))
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(listOf(c.glassBorderTop, c.glassBorderBottom)),
                shape = shape
            ),
        content = content
    )
}

fun formatTimeMs(ms: Long): String {
    if (ms <= 0L) return "0:00"
    val totalSec = ms / 1000L
    val hrs = totalSec / 3600L
    val mins = (totalSec % 3600L) / 60L
    val secs = totalSec % 60L
    return if (hrs > 0) String.format("%d:%02d:%02d", hrs, mins, secs)
    else String.format("%d:%02d", mins, secs)
}

fun formatFileSize(bytes: Long): String {
    if (bytes <= 0L) return "0 MB"
    val gb = bytes / (1024.0 * 1024.0 * 1024.0)
    if (gb >= 1.0) return String.format("%.2f GB", gb)
    val mb = bytes / (1024.0 * 1024.0)
    return String.format("%.1f MB", mb)
}
