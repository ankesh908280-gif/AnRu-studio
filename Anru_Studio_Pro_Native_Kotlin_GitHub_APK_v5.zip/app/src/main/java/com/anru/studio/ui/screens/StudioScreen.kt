package com.anru.studio.ui.screens

import android.net.Uri
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.BluetoothAudio
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.anru.studio.data.model.AppThemeMode
import com.anru.studio.tools.VaultAuthHelper
import com.anru.studio.ui.AnruViewModel
import com.anru.studio.ui.components.MediaArtwork
import com.anru.studio.ui.components.SongArtwork
import com.anru.studio.ui.theme.LiquidGlassBox
import com.anru.studio.ui.theme.LocalAnruColors
import com.anru.studio.ui.theme.OriginSpringFloat
import com.anru.studio.ui.theme.formatFileSize
import kotlinx.coroutines.launch

@Composable
fun StudioScreen(
    vm: AnruViewModel,
    onPickAvatar: () -> Unit,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
    onRequestDeleteUris: (List<Uri>) -> Unit
) {
    val c = LocalAnruColors.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs by vm.userPrefs.collectAsState()
    val songs by vm.visibleSongs.collectAsState()
    val videos by vm.visibleVideos.collectAsState()
    val history by vm.playHistory.collectAsState()
    val allFolders by vm.allMediaFolders.collectAsState()
    val hiddenFolders by vm.hiddenFolders.collectAsState()
    val duplicates by vm.duplicateGroups.collectAsState()
    val vaultedSongs by vm.vaultedSongs.collectAsState()
    val vaultedVideos by vm.vaultedVideos.collectAsState()

    var timeframe by remember { mutableStateOf("week") } // week, month, year
    val filteredHistory = remember(history, timeframe) { vm.filterHistoryByTimeframe(history, timeframe) }
    val chartStats = remember(history, timeframe) { vm.computeActivityStats(history, timeframe) }
    val topSongs = remember(filteredHistory) { vm.computeTopSongs(filteredHistory) }
    val totalMinutes = remember(filteredHistory) { filteredHistory.sumOf { it.durationSec } / 60 }
    val songMap = remember(songs) { songs.associateBy { it.id } }

    var showNameDialog by remember { mutableStateOf(false) }
    var showFolderFilterDialog by remember { mutableStateOf(false) }
    var showDuplicatesDialog by remember { mutableStateOf(false) }
    var showVaultPinDialog by remember { mutableStateOf(false) }
    var showVaultUnlocked by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 185.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Holographic Profile Card with Camera Avatar Picker Badge (No duplicate refresh button!)
        LiquidGlassBox(elevated = true, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(70.dp)
                        .clickable { onPickAvatar() }
                ) {
                    MediaArtwork(model = prefs.profileAvatarUri, size = 68.dp, cornerRadius = 34.dp)
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(c.accentPrimary, c.accentSecondary)))
                            .border(1.5.dp, c.bgTop, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.CameraAlt, contentDescription = "Change Photo", tint = Color.Black, modifier = Modifier.size(13.dp))
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = prefs.profileName,
                            color = c.textPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Icon(
                            Icons.Rounded.Edit,
                            contentDescription = "Edit Name",
                            tint = c.accentPrimary,
                            modifier = Modifier.size(16.dp).clickable { showNameDialog = true }
                        )
                    }
                    Spacer(Modifier.height(2.dp))
                    Text("${songs.size} Songs • ${videos.size} Videos", color = c.textMuted, fontSize = 12.sp)
                    Text("Tap photo to set from Gallery", color = c.accentPrimary.copy(alpha = 0.85f), fontSize = 11.sp)
                }
            }
        }

        // ONLY 2 THEMES: Origin Glass (iOS / OriginOS 7) & Cyber
        StudioSectionTitle(Icons.Rounded.Palette, "App Theme")
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AppThemeMode.entries.forEach { mode ->
                val selected = prefs.themeMode == mode
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            if (selected) Brush.horizontalGradient(listOf(c.accentPrimary, c.accentSecondary))
                            else Brush.horizontalGradient(listOf(c.glassSurface, c.glassSurface))
                        )
                        .border(1.dp, if (selected) Color.Transparent else c.glassBorderTop, RoundedCornerShape(18.dp))
                        .clickable { scope.launch { vm.prefs.setTheme(mode) } }
                        .padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = mode.label,
                        color = if (selected) Color.Black else c.textPrimary,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.5.sp
                    )
                }
            }
        }

        // Accurate Listening Activity Graph (7 Days / 1 Month / 1 Year)
        LiquidGlassBox(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Listening Activity", color = c.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
                        Text(
                            text = if (totalMinutes < 60) "${totalMinutes}m • ${filteredHistory.size} plays"
                            else "${String.format("%.1f", totalMinutes / 60f)}h • ${filteredHistory.size} plays",
                            color = c.accentPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("week" to "7D", "month" to "1M", "year" to "1Y").forEach { (key, lbl) ->
                            val act = timeframe == key
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(if (act) c.accentPrimary else Color.White.copy(alpha = 0.08f))
                                    .clickable { timeframe = key }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Text(lbl, color = if (act) Color.Black else c.textSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                val maxMin = (chartStats.maxOfOrNull { it.minutes } ?: 1).coerceAtLeast(1)
                val barWidth = if (timeframe == "year") 12.dp else 20.dp
                Row(
                    modifier = Modifier.fillMaxWidth().height(98.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.Bottom
                ) {
                    chartStats.forEach { st ->
                        val frac by animateFloatAsState(
                            targetValue = if (st.minutes == 0) 0.07f else (st.minutes.toFloat() / maxMin.toFloat()).coerceIn(0.14f, 1f),
                            animationSpec = OriginSpringFloat,
                            label = "bar_${st.label}"
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                            Box(
                                modifier = Modifier
                                    .width(barWidth)
                                    .fillMaxHeight(frac * 0.78f)
                                    .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                    .background(
                                        if (st.minutes > 0) Brush.verticalGradient(listOf(c.accentPrimary, c.accentSecondary))
                                        else Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.10f)))
                                    )
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = if (timeframe == "year") st.label.take(1) else st.label,
                                color = c.textMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }

        // Top 5 Most Played Songs Card
        LiquidGlassBox(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Rounded.EmojiEvents, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(19.dp))
                    Text("Top 5 Most Played", color = c.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
                }
                if (topSongs.isEmpty()) {
                    Text(
                        text = "Listen to songs for 15+ seconds to build your real Top 5 rankings!",
                        color = c.textMuted,
                        fontSize = 12.sp
                    )
                } else {
                    topSongs.forEachIndexed { idx, stat ->
                        val matchedSong = songMap[stat.songId]
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color.White.copy(alpha = 0.04f))
                                .clickable(enabled = matchedSong != null) {
                                    if (matchedSong != null) vm.playSong(matchedSong, songs)
                                }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "#${idx + 1}",
                                color = if (idx == 0) Color(0xFFF59E0B) else c.accentPrimary,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp,
                                modifier = Modifier.width(24.dp)
                            )
                            if (matchedSong != null) {
                                SongArtwork(song = matchedSong, size = 40.dp, cornerRadius = 10.dp)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(stat.title, color = c.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${stat.artist} • ${stat.playCount} plays", color = c.textMuted, fontSize = 11.sp, maxLines = 1)
                            }
                            if (matchedSong != null) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = "Play", tint = c.accentPrimary, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
        }

        // Smart Audio Filter & Bluetooth Controls
        StudioSectionTitle(Icons.Rounded.FilterList, "Smart Filter & Bluetooth")
        LiquidGlassBox(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                StudioSwitchRow(
                    title = "Hide Call Recordings",
                    subtitle = "Short songs & Reels always stay playable",
                    checked = prefs.filterCallRecordings
                ) { checked ->
                    scope.launch {
                        vm.prefs.setFilterCallRecordings(checked)
                        vm.scanDeviceMedia()
                    }
                }
                StudioSwitchRow(
                    title = "Hide WhatsApp Voice Notes",
                    subtitle = "Skip PTT voice notes & sent audio",
                    checked = prefs.filterWhatsAppVoice
                ) { checked ->
                    scope.launch {
                        vm.prefs.setFilterWhatsAppVoice(checked)
                        vm.scanDeviceMedia()
                    }
                }
                StudioSwitchRow(
                    title = "Bluetooth Auto-Resume",
                    subtitle = "Auto-resume on connect & pause on disconnect",
                    checked = prefs.bluetoothAutoResume
                ) { checked ->
                    scope.launch { vm.prefs.setBluetoothAutoResume(checked) }
                }
                TextButton(onClick = { showFolderFilterDialog = true }) {
                    Text("Manage Hidden Folders (${hiddenFolders.size})", color = c.accentPrimary, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Native Pro Tools (Private Vault, Duplicate Cleaner, Backup & Restore)
        StudioSectionTitle(Icons.Rounded.BluetoothAudio, "Pro Native Tools")

        StudioActionTile(
            icon = Icons.Rounded.Lock,
            title = "Private Vault (${vaultedSongs.size + vaultedVideos.size} Hidden)",
            subtitle = "Fingerprint / PIN lock for private songs & videos",
            tint = c.accentSecondary
        ) {
            val act = ctx as? FragmentActivity
            if (act != null && VaultAuthHelper.canUseBiometrics(ctx)) {
                VaultAuthHelper.authenticateBiometric(
                    activity = act,
                    onSuccess = { showVaultUnlocked = true },
                    onFallbackPin = { showVaultPinDialog = true }
                )
            } else {
                showVaultPinDialog = true
            }
        }

        StudioActionTile(
            icon = Icons.Rounded.CleaningServices,
            title = "Duplicate Media Cleaner",
            subtitle = "Find duplicate songs & videos to free phone space",
            tint = c.accentPrimary
        ) {
            vm.scanDuplicates()
            showDuplicatesDialog = true
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            LiquidGlassBox(
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.weight(1f).clickable { onExportBackup() }
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Rounded.Backup, contentDescription = null, tint = c.accentPrimary)
                    Text("Backup JSON", color = c.textPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
            LiquidGlassBox(
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.weight(1f).clickable { onImportBackup() }
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Rounded.Restore, contentDescription = null, tint = c.accentSecondary)
                    Text("Restore JSON", color = c.textPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }

    // Edit Profile Name Dialog
    if (showNameDialog) {
        var nameInput by remember { mutableStateOf(prefs.profileName) }
        AlertDialog(
            onDismissRequest = { showNameDialog = false },
            title = { Text("Edit Profile Name") },
            text = { OutlinedTextField(value = nameInput, onValueChange = { nameInput = it }, singleLine = true) },
            confirmButton = {
                Button(onClick = {
                    scope.launch { vm.prefs.setProfileName(nameInput) }
                    showNameDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showNameDialog = false }) { Text("Cancel") } }
        )
    }

    // Custom Folder Hide/Show Dialog
    if (showFolderFilterDialog) {
        AlertDialog(
            onDismissRequest = { showFolderFilterDialog = false },
            title = { Text("Hide / Show Folders") },
            text = {
                Column(modifier = Modifier.height(300.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    allFolders.forEach { folder ->
                        val isHidden = hiddenFolders.any { it.equals(folder, ignoreCase = true) }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(folder, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Switch(checked = !isHidden, onCheckedChange = { vm.toggleFolderHidden(folder) })
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showFolderFilterDialog = false }) { Text("Done") } }
        )
    }

    // Duplicate Cleaner Dialog
    if (showDuplicatesDialog) {
        AlertDialog(
            onDismissRequest = { showDuplicatesDialog = false },
            title = { Text("Duplicate Media Cleaner") },
            text = {
                Column(modifier = Modifier.height(320.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (duplicates.isEmpty()) {
                        Text("No duplicate songs or videos found! Your storage is clean.")
                    } else {
                        duplicates.forEach { grp ->
                            LiquidGlassBox(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "${if (grp.isVideo) "Video" else "Song"} • ${grp.items.size} copies (${formatFileSize(grp.sizeBytes)} each)",
                                        color = c.accentPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    grp.items.forEachIndexed { idx, entry ->
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(entry.title, color = c.textPrimary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text(entry.folderName, color = c.textMuted, fontSize = 10.sp)
                                            }
                                            if (idx > 0) {
                                                IconButton(onClick = {
                                                    onRequestDeleteUris(listOf(entry.uri))
                                                    showDuplicatesDialog = false
                                                }) {
                                                    Icon(Icons.Rounded.Delete, contentDescription = "Delete copy", tint = c.danger, modifier = Modifier.size(18.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showDuplicatesDialog = false }) { Text("Close") } }
        )
    }

    // Vault PIN Setup / Unlock Dialog
    if (showVaultPinDialog) {
        var pinInput by remember { mutableStateOf("") }
        val hasPin = prefs.vaultPin.isNotEmpty()
        AlertDialog(
            onDismissRequest = { showVaultPinDialog = false },
            title = { Text(if (hasPin) "Enter Vault PIN" else "Set 4-Digit Vault PIN") },
            text = {
                OutlinedTextField(
                    value = pinInput,
                    onValueChange = { if (it.length <= 6) pinInput = it.filter { ch -> ch.isDigit() } },
                    placeholder = { Text("Enter 4-digit PIN") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (!hasPin && pinInput.length >= 4) {
                        scope.launch { vm.prefs.setVaultPin(pinInput) }
                        showVaultPinDialog = false
                        showVaultUnlocked = true
                    } else if (hasPin && pinInput == prefs.vaultPin) {
                        showVaultPinDialog = false
                        showVaultUnlocked = true
                    } else {
                        vm.showToast("Invalid PIN")
                    }
                }) { Text(if (hasPin) "Unlock" else "Save PIN") }
            },
            dismissButton = { TextButton(onClick = { showVaultPinDialog = false }) { Text("Cancel") } }
        )
    }

    // Unlocked Private Vault Dialog
    if (showVaultUnlocked) {
        AlertDialog(
            onDismissRequest = { showVaultUnlocked = false },
            title = { Text("Private Vault (Unlocked)") },
            text = {
                Column(modifier = Modifier.height(320.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (vaultedSongs.isEmpty() && vaultedVideos.isEmpty()) {
                        Text("Vault is empty. Use the 3-dots menu on any song or video to hide it here.")
                    }
                    vaultedSongs.forEach { s ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { vm.playSong(s, vaultedSongs) }) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("🎵 ${s.title}", fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(s.artist, color = c.textMuted, fontSize = 11.sp)
                            }
                            IconButton(onClick = { vm.removeFromVault(s.id, isVideo = false) }) {
                                Icon(Icons.Rounded.LockOpen, contentDescription = "Unhide", tint = c.accentPrimary)
                            }
                        }
                    }
                    vaultedVideos.forEach { v ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable {
                            showVaultUnlocked = false
                            vm.openVideo(v, vaultedVideos)
                        }) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("🎬 ${v.title}", fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(formatFileSize(v.sizeBytes), color = c.textMuted, fontSize = 11.sp)
                            }
                            IconButton(onClick = { vm.removeFromVault(v.id, isVideo = true) }) {
                                Icon(Icons.Rounded.LockOpen, contentDescription = "Unhide", tint = c.accentPrimary)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showVaultUnlocked = false },
                    colors = ButtonDefaults.buttonColors(containerColor = c.accentPrimary)
                ) { Text("Lock Vault", color = Color.Black, fontWeight = FontWeight.Bold) }
            }
        )
    }
}

@Composable
private fun StudioSectionTitle(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String) {
    val c = LocalAnruColors.current
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(icon, contentDescription = null, tint = c.accentPrimary, modifier = Modifier.size(18.dp))
        Text(title, color = c.textPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
    }
}

@Composable
private fun StudioSwitchRow(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val c = LocalAnruColors.current
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, color = c.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.5.sp)
            Text(subtitle, color = c.textMuted, fontSize = 11.5.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun StudioActionTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    tint: Color,
    onClick: () -> Unit
) {
    val c = LocalAnruColors.current
    LiquidGlassBox(
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(tint.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = tint)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = c.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(subtitle, color = c.textMuted, fontSize = 11.5.sp)
            }
        }
    }
}
