package com.anru.studio.ui

import android.app.Application
import android.app.PendingIntent
import android.content.ComponentName
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.anru.studio.data.db.AnruDatabase
import com.anru.studio.data.db.FavoriteEntity
import com.anru.studio.data.db.HiddenFolderEntity
import com.anru.studio.data.db.PlayHistoryEntity
import com.anru.studio.data.db.PlaylistEntity
import com.anru.studio.data.db.PlaylistSongCrossRef
import com.anru.studio.data.db.TagOverrideEntity
import com.anru.studio.data.db.VaultItemEntity
import com.anru.studio.data.db.VideoProgressEntity
import com.anru.studio.data.model.AppThemeMode
import com.anru.studio.data.model.DuplicateGroup
import com.anru.studio.data.model.ListeningDayStat
import com.anru.studio.data.model.MainTab
import com.anru.studio.data.model.RepeatMode
import com.anru.studio.data.model.SongItem
import com.anru.studio.data.model.SongSort
import com.anru.studio.data.model.TopSongStat
import com.anru.studio.data.model.VideoFolder
import com.anru.studio.data.model.VideoItem
import com.anru.studio.data.model.VideoSort
import com.anru.studio.data.prefs.AnruPreferences
import com.anru.studio.data.prefs.UserPrefs
import com.anru.studio.data.repository.MediaRepository
import com.anru.studio.player.PlaybackService
import com.anru.studio.tools.BackupManager
import com.anru.studio.tools.DuplicateScanner
import com.anru.studio.tools.RingtoneTrimmer
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AnruViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AnruDatabase.getInstance(application)
    val dao = db.dao()
    val prefs = AnruPreferences(application)
    val repo = MediaRepository(application)

    val userPrefs: StateFlow<UserPrefs> = prefs.prefsFlow.stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        UserPrefs()
    )

    val playlists = dao.observePlaylists().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val playlistRefs = dao.observeAllPlaylistRefs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val favoriteIds = dao.observeFavoriteIds().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val playHistory = dao.observePlayHistory().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val videoProgressList = dao.observeVideoProgress().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val tagOverrides = dao.observeTagOverrides().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val vaultItems = dao.observeVaultItems().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val hiddenFolders = dao.observeHiddenFolders().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _rawSongs = MutableStateFlow<List<SongItem>>(emptyList())
    private val _rawVideos = MutableStateFlow<List<VideoItem>>(emptyList())

    val allScannedSongs: StateFlow<List<SongItem>> = _rawSongs.asStateFlow()
    val allScannedVideos: StateFlow<List<VideoItem>> = _rawVideos.asStateFlow()

    val visibleSongs: StateFlow<List<SongItem>> = combine(
        _rawSongs, vaultItems, hiddenFolders, tagOverrides
    ) { songs, vault, hidden, overrides ->
        val vaultedIds = vault.filter { !it.isVideo }.map { it.mediaId }.toSet()
        val hiddenSet = hidden.map { it.lowercase() }.toSet()
        val tagMap = overrides.associateBy { it.songId }
        songs.filter { it.id !in vaultedIds && it.folderName.lowercase() !in hiddenSet }
            .map { s ->
                val ov = tagMap[s.id]
                if (ov != null) s.copy(
                    title = ov.title.ifBlank { s.title },
                    artist = ov.artist.ifBlank { s.artist },
                    album = ov.album.ifBlank { s.album },
                    customArtUri = ov.customArtUri
                ) else s
            }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val visibleVideos: StateFlow<List<VideoItem>> = combine(
        _rawVideos, vaultItems, hiddenFolders, videoProgressList
    ) { videos, vault, hidden, progList ->
        val vaultedIds = vault.filter { it.isVideo }.map { it.mediaId }.toSet()
        val hiddenSet = hidden.map { it.lowercase() }.toSet()
        val progMap = progList.associateBy { it.videoId }
        videos.filter { it.id !in vaultedIds && it.folderName.lowercase() !in hiddenSet }
            .map { v ->
                val p = progMap[v.id]
                if (p != null) v.copy(lastPositionMs = p.lastPositionMs, lastWatchedAt = p.lastWatchedAt) else v
            }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val vaultedSongs: StateFlow<List<SongItem>> = combine(_rawSongs, vaultItems) { songs, vault ->
        val ids = vault.filter { !it.isVideo }.map { it.mediaId }.toSet()
        songs.filter { it.id in ids }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val vaultedVideos: StateFlow<List<VideoItem>> = combine(_rawVideos, vaultItems) { videos, vault ->
        val ids = vault.filter { it.isVideo }.map { it.mediaId }.toSet()
        videos.filter { it.id in ids }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val allMediaFolders: StateFlow<List<String>> = combine(_rawSongs, _rawVideos) { songs, videos ->
        (songs.map { it.folderName } + videos.map { it.folderName }).distinct().sorted()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val videoFolders: StateFlow<List<VideoFolder>> = visibleVideos.map { videos ->
        videos.groupBy { it.folderName }
            .map { (name, list) -> VideoFolder(name, list.size, list.sumOf { it.sizeBytes }) }
            .sortedByDescending { it.videoCount }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // UI Navigation & Filters
    private val _currentTab = MutableStateFlow(MainTab.LIBRARY)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _songSearch = MutableStateFlow("")
    val songSearch: StateFlow<String> = _songSearch.asStateFlow()

    private val _songSort = MutableStateFlow(SongSort.DATE_NEW)
    val songSort: StateFlow<SongSort> = _songSort.asStateFlow()

    private val _videoSearch = MutableStateFlow("")
    val videoSearch: StateFlow<String> = _videoSearch.asStateFlow()

    private val _videoSort = MutableStateFlow(VideoSort.DATE_NEW)
    val videoSort: StateFlow<VideoSort> = _videoSort.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // Active Video Player Overlay State
    private val _activeVideo = MutableStateFlow<VideoItem?>(null)
    val activeVideo: StateFlow<VideoItem?> = _activeVideo.asStateFlow()

    private val _activeVideoQueue = MutableStateFlow<List<VideoItem>>(emptyList())
    val activeVideoQueue: StateFlow<List<VideoItem>> = _activeVideoQueue.asStateFlow()

    private val _isInPipMode = MutableStateFlow(false)
    val isInPipMode: StateFlow<Boolean> = _isInPipMode.asStateFlow()

    // Music Playback State (synced with PlaybackService MediaController)
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    private val _currentSong = MutableStateFlow<SongItem?>(null)
    val currentSong: StateFlow<SongItem?> = _currentSong.asStateFlow()

    private val _queue = MutableStateFlow<List<SongItem>>(emptyList())
    val queue: StateFlow<List<SongItem>> = _queue.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _repeatMode = MutableStateFlow(RepeatMode.ALL)
    val repeatMode: StateFlow<RepeatMode> = _repeatMode.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    // Sleep Timer (including End of Track)
    private val _sleepTimerRemainingSec = MutableStateFlow(0)
    val sleepTimerRemainingSec: StateFlow<Int> = _sleepTimerRemainingSec.asStateFlow()
    private val _sleepAtEndOfTrack = MutableStateFlow(false)
    val sleepAtEndOfTrack: StateFlow<Boolean> = _sleepAtEndOfTrack.asStateFlow()
    private var sleepTimerJob: Job? = null

    // Real elapsed listening tracker (prevents fake plays on skip!)
    private var trackedSong: SongItem? = null
    private var trackedElapsedMs: Long = 0L
    private var lastTickWallMs: Long = 0L

    // Duplicates scan cache
    private val _duplicateGroups = MutableStateFlow<List<DuplicateGroup>>(emptyList())
    val duplicateGroups: StateFlow<List<DuplicateGroup>> = _duplicateGroups.asStateFlow()

    init {
        connectToPlaybackService()
        startProgressTicker()
    }

    private fun connectToPlaybackService() {
        val ctx = getApplication<Application>()
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                val ctrl = future.get()
                mediaController = ctrl
                ctrl.repeatMode = Player.REPEAT_MODE_ALL
                ctrl.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        _isPlaying.value = isPlaying
                        if (isPlaying) {
                            lastTickWallMs = System.currentTimeMillis()
                            if (trackedSong == null) trackedSong = _currentSong.value
                        } else {
                            flushTrackedListeningTime(reset = false)
                        }
                    }

                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        flushTrackedListeningTime(reset = true)
                        if (_sleepAtEndOfTrack.value && reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
                            _sleepAtEndOfTrack.value = false
                            ctrl.pause()
                            showToast("Sleep Timer ended — Track finished")
                        }
                        val id = mediaItem?.mediaId?.toLongOrNull() ?: return
                        val matched = _queue.value.find { it.id == id } ?: _rawSongs.value.find { it.id == id }
                        if (matched != null) {
                            _currentSong.value = matched
                            trackedSong = matched
                            trackedElapsedMs = 0L
                            lastTickWallMs = System.currentTimeMillis()
                        }
                    }

                    override fun onPlaybackStateChanged(playbackState: Int) {
                        val dur = ctrl.duration
                        if (dur > 0) _durationMs.value = dur
                    }
                })
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    private fun startProgressTicker() {
        viewModelScope.launch {
            while (isActive) {
                mediaController?.let { ctrl ->
                    if (ctrl.isPlaying) {
                        val now = System.currentTimeMillis()
                        if (lastTickWallMs > 0L) {
                            val delta = (now - lastTickWallMs).coerceIn(0L, 1500L)
                            trackedElapsedMs += delta
                        }
                        lastTickWallMs = now
                        _positionMs.value = ctrl.currentPosition.coerceAtLeast(0L)
                        val dur = ctrl.duration
                        if (dur > 0) _durationMs.value = dur
                    } else {
                        lastTickWallMs = 0L
                    }
                }
                delay(350)
            }
        }
    }

    private fun flushTrackedListeningTime(reset: Boolean) {
        val song = trackedSong ?: return
        val sec = (trackedElapsedMs / 1000L).toInt()
        if (sec >= 15) {
            viewModelScope.launch {
                dao.insertPlayHistory(
                    PlayHistoryEntity(
                        songId = song.id,
                        title = song.title,
                        artist = song.artist,
                        durationSec = sec.coerceAtMost(1800)
                    )
                )
            }
            trackedElapsedMs = 0L
        }
        if (reset) {
            trackedElapsedMs = 0L
            trackedSong = null
        }
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
        viewModelScope.launch {
            delay(2600)
            if (_toastMessage.value == msg) _toastMessage.value = null
        }
    }

    fun setTab(tab: MainTab) { _currentTab.value = tab }
    fun setSongSearch(q: String) { _songSearch.value = q }
    fun setSongSort(sort: SongSort) { _songSort.value = sort }
    fun setVideoSearch(q: String) { _videoSearch.value = q }
    fun setVideoSort(sort: VideoSort) { _videoSort.value = sort }
    fun setPipMode(inPip: Boolean) { _isInPipMode.value = inPip }

    fun scanDeviceMedia() {
        viewModelScope.launch {
            _isScanning.value = true
            val p = userPrefs.value
            val overrides = tagOverrides.value.associateBy { it.songId }
            val progMap = videoProgressList.value.associateBy { it.videoId }
            val songs = repo.scanAllSongs(p.filterCallRecordings, p.filterWhatsAppVoice, overrides)
            val videos = repo.scanAllVideos(progMap)
            _rawSongs.value = songs
            _rawVideos.value = videos
            _isScanning.value = false
        }
    }

    private fun SongItem.toMediaItem(): MediaItem {
        val artUri = customArtUri?.let { Uri.parse(it) } ?: albumArtUri
        val meta = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setArtworkUri(artUri)
            .build()
        return MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(uri)
            .setMediaMetadata(meta)
            .build()
    }

    fun playSong(song: SongItem, songQueue: List<SongItem> = visibleSongs.value) {
        val list = if (songQueue.any { it.id == song.id }) songQueue else listOf(song)
        val idx = list.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        _queue.value = list
        _currentSong.value = song
        _durationMs.value = song.durationMs
        _positionMs.value = 0L

        flushTrackedListeningTime(reset = true)
        trackedSong = song
        trackedElapsedMs = 0L
        lastTickWallMs = System.currentTimeMillis()

        mediaController?.let { ctrl ->
            ctrl.setMediaItems(list.map { it.toMediaItem() }, idx, 0L)
            ctrl.prepare()
            ctrl.play()
        }
    }

    fun togglePlayPause() {
        mediaController?.let { ctrl ->
            if (ctrl.isPlaying) ctrl.pause() else ctrl.play()
        }
    }

    fun pauseMusicForVideo() {
        mediaController?.let { if (it.isPlaying) it.pause() }
    }

    fun seekTo(posMs: Long) {
        mediaController?.seekTo(posMs.coerceAtLeast(0L))
        _positionMs.value = posMs.coerceAtLeast(0L)
    }

    fun nextSong() { mediaController?.seekToNextMediaItem() }
    fun previousSong() { mediaController?.seekToPreviousMediaItem() }

    fun toggleShuffle() {
        val next = !_isShuffle.value
        _isShuffle.value = next
        mediaController?.shuffleModeEnabled = next
        showToast(if (next) "Shuffle: ON" else "Shuffle: OFF")
    }

    fun cycleRepeatMode() {
        val next = when (_repeatMode.value) {
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
            RepeatMode.OFF -> RepeatMode.ALL
        }
        _repeatMode.value = next
        mediaController?.repeatMode = when (next) {
            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
        }
        showToast("Repeat: ${next.name}")
    }

    fun cyclePlaybackSpeed() {
        val speeds = listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val next = speeds[(speeds.indexOf(_playbackSpeed.value) + 1) % speeds.size]
        _playbackSpeed.value = next
        mediaController?.setPlaybackSpeed(next)
        showToast("Speed: ${next}x")
    }

    fun addToQueue(song: SongItem, playNext: Boolean = false) {
        val currentList = _queue.value.toMutableList()
        if (playNext && mediaController != null) {
            val insertIdx = (mediaController!!.currentMediaItemIndex + 1).coerceAtMost(currentList.size)
            currentList.add(insertIdx, song)
            _queue.value = currentList
            mediaController?.addMediaItem(insertIdx, song.toMediaItem())
            showToast("Playing next: ${song.title}")
        } else {
            currentList.add(song)
            _queue.value = currentList
            mediaController?.addMediaItem(song.toMediaItem())
            showToast("Added to Queue")
        }
    }

    fun moveQueueItem(fromIndex: Int, toIndex: Int) {
        val list = _queue.value.toMutableList()
        if (fromIndex !in list.indices || toIndex !in list.indices) return
        val item = list.removeAt(fromIndex)
        list.add(toIndex, item)
        _queue.value = list
        mediaController?.moveMediaItem(fromIndex, toIndex)
    }

    fun removeQueueItem(index: Int) {
        val list = _queue.value.toMutableList()
        if (index !in list.indices) return
        val removed = list.removeAt(index)
        _queue.value = list
        try { mediaController?.removeMediaItem(index) } catch (_: Exception) {}
        showToast("Removed '${removed.title}' from Queue")
    }

    fun applyDspLiveOnly(
        eqBands: List<Int>,
        bass: Int,
        virtualizer: Boolean,
        normalizer: Boolean,
        loudnessMb: Int
    ) {
        PlaybackService.dspEngine.applySettings(eqBands, bass, virtualizer, normalizer, loudnessMb)
    }

    fun setSleepEndOfTrack() {
        sleepTimerJob?.cancel()
        _sleepTimerRemainingSec.value = 0
        _sleepAtEndOfTrack.value = true
        showToast("Music will stop at end of current track")
    }

    fun clearAllSleepTimers() {
        sleepTimerJob?.cancel()
        _sleepTimerRemainingSec.value = 0
        _sleepAtEndOfTrack.value = false
        showToast("Sleep Timer OFF")
    }

    fun savePickedImageLocally(sourceUri: Uri, targetFileName: String): String? {
        return try {
            val ctx = getApplication<Application>()
            val outFile = java.io.File(ctx.filesDir, targetFileName)
            ctx.contentResolver.openInputStream(sourceUri)?.use { input ->
                outFile.outputStream().use { output -> input.copyTo(output) }
            }
            Uri.fromFile(outFile).toString() + "?t=" + System.currentTimeMillis()
        } catch (_: Exception) {
            sourceUri.toString()
        }
    }

    // DSP Controls
    fun applyDspUpdate(
        eqBands: List<Int> = userPrefs.value.eqBands,
        bass: Int = userPrefs.value.bassBoostLevel,
        virtualizer: Boolean = userPrefs.value.virtualizerOn,
        normalizer: Boolean = userPrefs.value.normalizerOn,
        loudnessMb: Int = userPrefs.value.loudnessBoostMb
    ) {
        viewModelScope.launch {
            prefs.setEqBands(eqBands)
            prefs.setBassBoost(bass)
            prefs.setVirtualizer(virtualizer)
            prefs.setNormalizer(normalizer)
            prefs.setLoudnessBoost(loudnessMb)
            PlaybackService.dspEngine.applySettings(eqBands, bass, virtualizer, normalizer, loudnessMb)
        }
    }

    // Sleep Timer
    fun setSleepTimerMinutes(minutes: Int) {
        sleepTimerJob?.cancel()
        if (minutes <= 0) {
            _sleepTimerRemainingSec.value = 0
            showToast("Sleep Timer OFF")
            return
        }
        _sleepTimerRemainingSec.value = minutes * 60
        showToast("Sleep Timer set for $minutes min")
        sleepTimerJob = viewModelScope.launch {
            while (_sleepTimerRemainingSec.value > 0) {
                delay(1000)
                _sleepTimerRemainingSec.value -= 1
            }
            mediaController?.pause()
            showToast("Sleep Timer ended — Music paused")
        }
    }

    // Playlists & Favorites
    fun toggleFavorite(songId: Long) {
        viewModelScope.launch {
            if (songId in favoriteIds.value) {
                dao.removeFavorite(songId)
            } else {
                dao.addFavorite(FavoriteEntity(songId))
            }
        }
    }

    fun createPlaylist(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            dao.insertPlaylist(PlaylistEntity(name = name.trim()))
            showToast("Playlist '$name' created")
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            dao.clearPlaylistSongs(playlistId)
            dao.deletePlaylist(playlistId)
            showToast("Playlist deleted")
        }
    }

    fun addSongToPlaylist(playlistId: Long, songId: Long) {
        viewModelScope.launch {
            dao.addSongToPlaylist(PlaylistSongCrossRef(playlistId, songId))
            showToast("Added to playlist")
        }
    }

    fun removeSongFromPlaylist(playlistId: Long, songId: Long) {
        viewModelScope.launch {
            dao.removeSongFromPlaylist(playlistId, songId)
        }
    }

    // Tag & Cover Art Editor
    fun saveTagOverride(songId: Long, title: String, artist: String, album: String, customArtUri: String?) {
        viewModelScope.launch {
            dao.upsertTagOverride(
                TagOverrideEntity(
                    songId = songId,
                    title = title.trim(),
                    artist = artist.trim(),
                    album = album.trim(),
                    customArtUri = customArtUri
                )
            )
            showToast("Song tags updated!")
        }
    }

    // Video Player Controls
    fun openVideo(video: VideoItem, queue: List<VideoItem> = visibleVideos.value) {
        pauseMusicForVideo()
        _activeVideoQueue.value = queue
        _activeVideo.value = video
    }

    fun closeVideo() {
        _activeVideo.value = null
        _isInPipMode.value = false
    }

    fun saveVideoProgress(videoId: Long, positionMs: Long) {
        viewModelScope.launch {
            dao.upsertVideoProgress(VideoProgressEntity(videoId, positionMs, System.currentTimeMillis()))
        }
    }

    fun clearVideoProgress(videoId: Long) {
        viewModelScope.launch {
            dao.clearVideoProgress(videoId)
            showToast("Resume position reset")
        }
    }

    // Private Vault
    fun moveToVault(mediaId: Long, isVideo: Boolean) {
        viewModelScope.launch {
            val key = if (isVideo) "video_$mediaId" else "song_$mediaId"
            dao.addToVault(VaultItemEntity(key, mediaId, isVideo))
            showToast("Moved to Private Vault")
        }
    }

    fun removeFromVault(mediaId: Long, isVideo: Boolean) {
        viewModelScope.launch {
            val key = if (isVideo) "video_$mediaId" else "song_$mediaId"
            dao.removeFromVault(key)
            showToast("Restored from Vault")
        }
    }

    // Folder Filter Blacklist
    fun toggleFolderHidden(folderName: String) {
        viewModelScope.launch {
            if (hiddenFolders.value.any { it.equals(folderName, ignoreCase = true) }) {
                dao.unhideFolder(folderName)
            } else {
                dao.hideFolder(HiddenFolderEntity(folderName))
            }
        }
    }

    // Real MediaStore Delete Request (Android 11+ PendingIntent or Android 8-10 direct delete)
    fun buildDeleteRequest(uris: List<Uri>): PendingIntent? = repo.buildDeletePendingIntent(uris)

    fun deleteLegacyMedia(uris: List<Uri>) {
        viewModelScope.launch {
            val count = repo.deleteLegacyUris(uris)
            if (count > 0) {
                showToast("Deleted $count file(s)")
                scanDeviceMedia()
            }
        }
    }

    // Duplicate Media Cleaner
    fun scanDuplicates() {
        viewModelScope.launch {
            _duplicateGroups.value = DuplicateScanner.findDuplicates(_rawSongs.value, _rawVideos.value)
        }
    }

    // Ringtone Trimmer
    fun trimRingtone(
        song: SongItem,
        startMs: Long,
        endMs: Long,
        setAsDefault: Boolean,
        onDone: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val res = RingtoneTrimmer.trimAndSaveRingtone(
                context = getApplication(),
                sourceUri = song.uri,
                outputTitle = song.title,
                startMs = startMs,
                endMs = endMs,
                setAsDefaultRingtone = setAsDefault
            )
            res.onSuccess {
                scanDeviceMedia()
                onDone(true, if (setAsDefault) "Ringtone saved & set as default!" else "Trimmed audio saved in Ringtones/AnruStudio!")
            }.onFailure { err ->
                onDone(false, err.message ?: "Could not trim this audio format")
            }
        }
    }

    // Backup & Restore JSON
    fun exportBackupToUri(uri: Uri) {
        viewModelScope.launch {
            try {
                val json = BackupManager.exportJson(dao)
                getApplication<Application>().contentResolver.openOutputStream(uri)?.use {
                    it.write(json.toByteArray(Charsets.UTF_8))
                }
                showToast("Backup exported successfully!")
            } catch (e: Exception) {
                showToast("Backup failed: ${e.message}")
            }
        }
    }

    fun importBackupFromUri(uri: Uri) {
        viewModelScope.launch {
            try {
                val json = getApplication<Application>().contentResolver.openInputStream(uri)?.use {
                    it.readBytes().toString(Charsets.UTF_8)
                } ?: ""
                val count = BackupManager.importJson(dao, json)
                showToast("Restored $count items from backup!")
                scanDeviceMedia()
            } catch (e: Exception) {
                showToast("Restore failed: ${e.message}")
            }
        }
    }

    // Listening Activity Stats
    private fun logSongPlay(song: SongItem) {
        viewModelScope.launch {
            val durSec = (song.durationMs / 1000L).toInt().coerceIn(15, 600)
            dao.insertPlayHistory(
                PlayHistoryEntity(
                    songId = song.id,
                    title = song.title,
                    artist = song.artist,
                    durationSec = durSec
                )
            )
        }
    }

    fun filterHistoryByTimeframe(history: List<PlayHistoryEntity>, timeframe: String): List<PlayHistoryEntity> {
        val now = System.currentTimeMillis()
        val days = when (timeframe) {
            "month" -> 30L
            "year" -> 365L
            else -> 7L
        }
        val cutoff = now - days * 86_400_000L
        return history.filter { it.timestamp >= cutoff }
    }

    fun computeActivityStats(history: List<PlayHistoryEntity>, timeframe: String): List<ListeningDayStat> {
        val cal = Calendar.getInstance()
        val nowMs = System.currentTimeMillis()
        return when (timeframe) {
            "month" -> {
                val weekMs = 7L * 86_400_000L
                val buckets = IntArray(4)
                history.forEach { h ->
                    val age = nowMs - h.timestamp
                    if (age in 0 until (weekMs * 4)) {
                        val idx = (3 - (age / weekMs).toInt()).coerceIn(0, 3)
                        buckets[idx] += h.durationSec
                    }
                }
                listOf(
                    ListeningDayStat("W1", buckets[0] / 60),
                    ListeningDayStat("W2", buckets[1] / 60),
                    ListeningDayStat("W3", buckets[2] / 60),
                    ListeningDayStat("W4", buckets[3] / 60)
                )
            }
            "year" -> {
                val months = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
                val curYear = cal.get(Calendar.YEAR)
                val buckets = IntArray(12)
                history.forEach { h ->
                    val c = Calendar.getInstance().apply { timeInMillis = h.timestamp }
                    if (c.get(Calendar.YEAR) == curYear) {
                        buckets[c.get(Calendar.MONTH)] += h.durationSec
                    }
                }
                months.mapIndexed { idx, label -> ListeningDayStat(label, buckets[idx] / 60) }
            }
            else -> {
                val fmt = SimpleDateFormat("EEE", Locale.getDefault())
                val dayKeyFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                val byDay = history.groupBy { dayKeyFmt.format(it.timestamp) }
                val result = mutableListOf<ListeningDayStat>()
                for (i in 6 downTo 0) {
                    val c = (cal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -i) }
                    val key = dayKeyFmt.format(c.time)
                    val mins = ((byDay[key]?.sumOf { it.durationSec } ?: 0) / 60)
                    result.add(ListeningDayStat(fmt.format(c.time), mins))
                }
                result
            }
        }
    }

    fun computeTopSongs(history: List<PlayHistoryEntity>): List<TopSongStat> {
        return history.groupBy { it.songId }
            .map { (id, list) ->
                val first = list.first()
                TopSongStat(id, first.title, first.artist, list.size)
            }
            .sortedByDescending { it.playCount }
            .take(5)
    }

    override fun onCleared() {
        sleepTimerJob?.cancel()
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onCleared()
    }
}
