package com.anru.studio.player

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer

class AudioDspEngine {
    private var sessionId: Int = 0
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null

    fun attachToSession(audioSessionId: Int) {
        if (audioSessionId <= 0 || audioSessionId == sessionId) return
        release()
        sessionId = audioSessionId
        try {
            equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
        } catch (_: Exception) {}
        try {
            bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
        } catch (_: Exception) {}
        try {
            virtualizer = Virtualizer(0, audioSessionId).apply { enabled = false }
        } catch (_: Exception) {}
        try {
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply { enabled = false }
        } catch (_: Exception) {}
    }

    fun applySettings(
        eqBandsDb: List<Int>,
        bassLevel: Int,
        virtualizerOn: Boolean,
        normalizerOn: Boolean,
        loudnessBoostMb: Int
    ) {
        try {
            equalizer?.let { eq ->
                val numBands = eq.numberOfBands.toInt()
                val range = eq.bandLevelRange
                val minLevel = range[0].toInt()
                val maxLevel = range[1].toInt()
                for (i in 0 until numBands) {
                    val db = eqBandsDb.getOrElse(i) { 0 }
                    val mb = (db * 100).coerceIn(minLevel, maxLevel).toShort()
                    eq.setBandLevel(i.toShort(), mb)
                }
            }
        } catch (_: Exception) {}

        try {
            bassBoost?.let { bb ->
                val strength = bassLevel.coerceIn(0, 1000).toShort()
                bb.enabled = strength > 0
                if (strength > 0) bb.setStrength(strength)
            }
        } catch (_: Exception) {}

        try {
            virtualizer?.let { vz ->
                vz.enabled = virtualizerOn
                if (virtualizerOn) vz.setStrength(750.toShort())
            }
        } catch (_: Exception) {}

        try {
            loudnessEnhancer?.let { le ->
                val targetMb = (loudnessBoostMb + if (normalizerOn) 250 else 0).coerceIn(0, 1200)
                le.enabled = targetMb > 0
                if (targetMb > 0) le.setTargetGain(targetMb)
            }
        } catch (_: Exception) {}
    }

    fun release() {
        try { equalizer?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        try { virtualizer?.release() } catch (_: Exception) {}
        try { loudnessEnhancer?.release() } catch (_: Exception) {}
        equalizer = null
        bassBoost = null
        virtualizer = null
        loudnessEnhancer = null
        sessionId = 0
    }
}
