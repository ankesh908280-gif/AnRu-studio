package com.anru.studio.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.anru.studio.data.model.AppThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.anruDataStore by preferencesDataStore(name = "anru_studio_prefs")

data class UserPrefs(
    val themeMode: AppThemeMode = AppThemeMode.ORIGIN_GLASS,
    val profileName: String = "Anru VIP Listener",
    val profileAvatarUri: String? = null,
    val filterCallRecordings: Boolean = true,
    val filterWhatsAppVoice: Boolean = true,
    val bluetoothAutoResume: Boolean = true,
    val virtualizerOn: Boolean = false,
    val normalizerOn: Boolean = false,
    val bassBoostLevel: Int = 0, // 0..1000
    val loudnessBoostMb: Int = 0, // 0..1000 (up to 200% feel)
    val eqBands: List<Int> = listOf(0, 0, 0, 0, 0),
    val vaultPin: String = "",
    val videoHdrOn: Boolean = false,
    val preferSoftwareVideoDecoder: Boolean = false
)

class AnruPreferences(private val context: Context) {

    private object Keys {
        val THEME = stringPreferencesKey("theme_mode")
        val PROFILE_NAME = stringPreferencesKey("profile_name")
        val PROFILE_AVATAR = stringPreferencesKey("profile_avatar")
        val FILTER_CALLS = booleanPreferencesKey("filter_calls")
        val FILTER_WA = booleanPreferencesKey("filter_wa")
        val BT_AUTO_RESUME = booleanPreferencesKey("bt_auto_resume")
        val VIRTUALIZER = booleanPreferencesKey("virtualizer_on")
        val NORMALIZER = booleanPreferencesKey("normalizer_on")
        val BASS_BOOST = intPreferencesKey("bass_boost")
        val LOUDNESS_BOOST = intPreferencesKey("loudness_boost")
        val EQ_BANDS = stringPreferencesKey("eq_bands")
        val VAULT_PIN = stringPreferencesKey("vault_pin")
        val VIDEO_HDR = booleanPreferencesKey("video_hdr")
        val SW_DECODER = booleanPreferencesKey("sw_decoder")
    }

    val prefsFlow: Flow<UserPrefs> = context.anruDataStore.data.map { p ->
        val themeStr = p[Keys.THEME] ?: AppThemeMode.ORIGIN_GLASS.key
        val theme = if (themeStr == AppThemeMode.CYBER.key) AppThemeMode.CYBER else AppThemeMode.ORIGIN_GLASS
        val eqStr = p[Keys.EQ_BANDS] ?: "0,0,0,0,0"
        val eqList = eqStr.split(",").mapNotNull { it.trim().toIntOrNull() }.ifEmpty { listOf(0, 0, 0, 0, 0) }
        UserPrefs(
            themeMode = theme,
            profileName = p[Keys.PROFILE_NAME] ?: "Anru VIP Listener",
            profileAvatarUri = p[Keys.PROFILE_AVATAR],
            filterCallRecordings = p[Keys.FILTER_CALLS] ?: true,
            filterWhatsAppVoice = p[Keys.FILTER_WA] ?: true,
            bluetoothAutoResume = p[Keys.BT_AUTO_RESUME] ?: true,
            virtualizerOn = p[Keys.VIRTUALIZER] ?: false,
            normalizerOn = p[Keys.NORMALIZER] ?: false,
            bassBoostLevel = p[Keys.BASS_BOOST] ?: 0,
            loudnessBoostMb = p[Keys.LOUDNESS_BOOST] ?: 0,
            eqBands = eqList,
            vaultPin = p[Keys.VAULT_PIN] ?: "",
            videoHdrOn = p[Keys.VIDEO_HDR] ?: false,
            preferSoftwareVideoDecoder = p[Keys.SW_DECODER] ?: false
        )
    }

    suspend fun setTheme(mode: AppThemeMode) {
        context.anruDataStore.edit { it[Keys.THEME] = mode.key }
    }

    suspend fun setProfileName(name: String) {
        context.anruDataStore.edit { it[Keys.PROFILE_NAME] = name.trim().ifEmpty { "Anru VIP Listener" } }
    }

    suspend fun setProfileAvatar(uri: String?) {
        context.anruDataStore.edit {
            if (uri.isNullOrBlank()) it.remove(Keys.PROFILE_AVATAR) else it[Keys.PROFILE_AVATAR] = uri
        }
    }

    suspend fun setFilterCallRecordings(enabled: Boolean) {
        context.anruDataStore.edit { it[Keys.FILTER_CALLS] = enabled }
    }

    suspend fun setFilterWhatsAppVoice(enabled: Boolean) {
        context.anruDataStore.edit { it[Keys.FILTER_WA] = enabled }
    }

    suspend fun setBluetoothAutoResume(enabled: Boolean) {
        context.anruDataStore.edit { it[Keys.BT_AUTO_RESUME] = enabled }
    }

    suspend fun setVirtualizer(enabled: Boolean) {
        context.anruDataStore.edit { it[Keys.VIRTUALIZER] = enabled }
    }

    suspend fun setNormalizer(enabled: Boolean) {
        context.anruDataStore.edit { it[Keys.NORMALIZER] = enabled }
    }

    suspend fun setBassBoost(level: Int) {
        context.anruDataStore.edit { it[Keys.BASS_BOOST] = level.coerceIn(0, 1000) }
    }

    suspend fun setLoudnessBoost(mb: Int) {
        context.anruDataStore.edit { it[Keys.LOUDNESS_BOOST] = mb.coerceIn(0, 1000) }
    }

    suspend fun setEqBands(bands: List<Int>) {
        context.anruDataStore.edit { it[Keys.EQ_BANDS] = bands.joinToString(",") }
    }

    suspend fun setVaultPin(pin: String) {
        context.anruDataStore.edit { it[Keys.VAULT_PIN] = pin }
    }

    suspend fun setVideoHdr(enabled: Boolean) {
        context.anruDataStore.edit { it[Keys.VIDEO_HDR] = enabled }
    }

    suspend fun setPreferSoftwareDecoder(enabled: Boolean) {
        context.anruDataStore.edit { it[Keys.SW_DECODER] = enabled }
    }
}
