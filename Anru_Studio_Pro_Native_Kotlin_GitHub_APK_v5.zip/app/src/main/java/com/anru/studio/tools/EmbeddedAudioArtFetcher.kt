package com.anru.studio.tools

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import coil.ImageLoader
import coil.decode.DataSource
import coil.decode.ImageSource
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.fetch.SourceResult
import coil.request.Options
import okio.Buffer

data class SongArtModel(
    val songUri: Uri,
    val customArtPath: String? = null
)

class EmbeddedAudioArtFetcher(
    private val context: Context,
    private val data: SongArtModel
) : Fetcher {

    override suspend fun fetch(): FetchResult? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, data.songUri)
            val bytes = retriever.embeddedPicture
            if (bytes != null && bytes.isNotEmpty()) {
                val buffer = Buffer().write(bytes)
                SourceResult(
                    source = ImageSource(buffer, context),
                    mimeType = null,
                    dataSource = DataSource.DISK
                )
            } else {
                null
            }
        } catch (_: Exception) {
            null
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }

    class Factory(private val context: Context) : Fetcher.Factory<SongArtModel> {
        override fun create(data: SongArtModel, options: Options, imageLoader: ImageLoader): Fetcher? {
            if (!data.customArtPath.isNullOrBlank()) return null
            return EmbeddedAudioArtFetcher(context, data)
        }
    }
}
